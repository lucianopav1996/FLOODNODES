# FLOODNODES - Technical Documentation

## Hydrological Model Specifications

### Peak Discharge Calculation

FLOODNODES uses the **Rational Method** to calculate peak discharge for different return periods:

**Formula:**
```
Qc(RP) = P × A / τc × 0.278
```

Where:
- **Qc(RP)** = Peak discharge for return period RP (m³/s)
- **P** = Net rainfall derived from SCS Curve Number method (mm)
- **A** = Drainage area (km²)
- **τc** = Time of concentration (hours)
- **0.278** = Unit conversion coefficient

### Curve Number and Soil Storage

The CN raster file represents the **maximum soil absorption capacity** derived from **Hawkins (2010)** methodology:

**Potential Maximum Retention (S):**
```
S = 1.33 × [254 × (100/CN - 1)]^1.15
```

**Initial Abstraction (Ia):**
```
Ia = 0.05 × S
```

Where:
- **S** = Potential maximum soil retention after runoff begins (mm)
- **CN** = Curve Number (dimensionless, 0-100)
- **Ia** = Initial abstraction (mm) - rainfall retained before runoff begins

### Key Assumptions

1. **Concentration Time**: Calculated using Giandotti formula (calibrated for basins <150 km²)
2. **Runoff Generation**: SCS-CN method with Hawkins (2010) S-Ia relationship
3. **Return Periods**: 2, 10, 25, 50, 100, 200, 500 years
4. **Sediment Bulking**: Factors from 1.05 to 1.5 applied to liquid discharge

## Validation Domain

**CRITICAL**: This model has been developed and validated for watersheds **≤ 150 km²**

### Limitations Beyond 150 km²:
- Giandotti formula may overestimate concentration time
- SCS-CN method accuracy decreases at larger scales
- Simplified hydraulic routing may miss complex flow dynamics
- Results require expert validation and recalibration

## Output Shapefiles

### 1. Drainage Basin (drainage_basin.shp)
- **Geometry**: Polygon
- **Fields**:
  - `Basin_ID`: Unique basin identifier
  - `Area_km2`: Drainage area in square kilometers

### 2. River Network (river_network.shp)
- **Geometry**: LineString
- **Fields**:
  - `Stream_ID`: Unique stream segment identifier
  - `Flow_Accum`: Flow accumulation value (cells)
  - `Length_m`: Stream segment length in meters

## References

- Hawkins, R. H., Ward, T. J., Woodward, D. E., & Van Mullem, J. A. (2010). Continuing evolution of rainfall-runoff and the curve number precedent. In Proceedings of the 2nd Joint Federal Interagency Conference, Las Vegas, NV (pp. 27-30).

## Project Information

**Funded by**: Italian National Recovery and Resilience Plan (PNRR)  
**CUP Code**: D43C22003030002  
**Scientific Coordinator**:prof. Fernando Nardi, PhD
**Task Leader**: Ing. Luciano Pavesi, PhD
**Project Coordinator**: IDRAN Ingegneria e Tecnologia S.r.l.