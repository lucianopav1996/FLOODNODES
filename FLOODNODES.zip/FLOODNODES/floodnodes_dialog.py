# -*- coding: utf-8 -*-
"""
FLOODNODES Dialog
GUI Interface for hydrological flood risk analysis
"""

import os
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, 
    QLabel, QLineEdit, QPushButton, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox, QFileDialog,
    QTableWidget, QTableWidgetItem, QMessageBox,
    QProgressBar, QTextEdit, QTabWidget, QWidget
)
from qgis.PyQt.QtGui import QFont
from qgis.gui import QgsFileWidget, QgsMapLayerComboBox, QgsFieldComboBox
from qgis.core import QgsMapLayerProxyModel, QgsRasterLayer, QgsVectorLayer
import pandas as pd


class FloodNodesDialog(QDialog):
    """Dialog for FLOODNODES Analysis"""
    
    def __init__(self, parent=None):
        """Constructor."""
        super(FloodNodesDialog, self).__init__(parent)
        self.setupUi()
        
        # Connect signals
        self.connectSignals()
        
        # Default values
        self.setDefaultValues()
        
    def setupUi(self):
        """Setup the user interface"""
        self.setWindowTitle("Flood Risk Analyzer - Multi Return Period Analysis")
        self.resize(900, 700)
        
        # Main layout
        main_layout = QVBoxLayout()
        
        # Tab widget
        self.tab_widget = QTabWidget()
        
        # Tab 1: Input Data
        tab_input = self.createInputTab()
        self.tab_widget.addTab(tab_input, "1. Dati Input")
        
        # Tab 2: Analysis Parameters
        tab_params = self.createParametersTab()
        self.tab_widget.addTab(tab_params, "2. Parametri Analisi")
        
        # Tab 3: Output Settings
        tab_output = self.createOutputTab()
        self.tab_widget.addTab(tab_output, "3. Output")
        
        main_layout.addWidget(self.tab_widget)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # Log area
        log_group = QGroupBox("Log Analisi")
        log_layout = QVBoxLayout()
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(150)
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        main_layout.addWidget(log_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.btn_run = QPushButton("Esegui Analisi")
        self.btn_run.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 8px;")
        
        self.btn_close = QPushButton("Chiudi")
        self.btn_close.setStyleSheet("padding: 8px;")
        
        button_layout.addStretch()
        button_layout.addWidget(self.btn_run)
        button_layout.addWidget(self.btn_close)
        
        main_layout.addLayout(button_layout)
        
        self.setLayout(main_layout)
    
    def createInputTab(self):
        """Create input data tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # DEM Data Group
        dem_group = QGroupBox("Dati DEM e Morfologia")
        dem_layout = QVBoxLayout()
        
        # DEM
        dem_row = QHBoxLayout()
        dem_row.addWidget(QLabel("DEM:"))
        self.dem_input = QgsFileWidget()
        self.dem_input.setFilter("GeoTIFF (*.tif *.tiff)")
        self.dem_input.setStorageMode(QgsFileWidget.GetFile)
        dem_row.addWidget(self.dem_input)
        dem_layout.addLayout(dem_row)
        
        # Flow Direction
        fd_row = QHBoxLayout()
        fd_row.addWidget(QLabel("Flow Direction:"))
        self.fd_input = QgsFileWidget()
        self.fd_input.setFilter("GeoTIFF (*.tif *.tiff)")
        self.fd_input.setStorageMode(QgsFileWidget.GetFile)
        fd_row.addWidget(self.fd_input)
        dem_layout.addLayout(fd_row)
        
        # Flow Accumulation
        acc_row = QHBoxLayout()
        acc_row.addWidget(QLabel("Flow Accumulation:"))
        self.acc_input = QgsFileWidget()
        self.acc_input.setFilter("GeoTIFF (*.tif *.tiff)")
        self.acc_input.setStorageMode(QgsFileWidget.GetFile)
        acc_row.addWidget(self.acc_input)
        dem_layout.addLayout(acc_row)
        
        dem_group.setLayout(dem_layout)
        layout.addWidget(dem_group)
        
        # CN Data Group
        cn_group = QGroupBox("Curve Number (CN)")
        cn_layout = QVBoxLayout()
        
        cn_row = QHBoxLayout()
        cn_row.addWidget(QLabel("File CN:"))
        self.cn_input = QgsFileWidget()
        self.cn_input.setFilter("GeoTIFF (*.tif *.tiff)")
        self.cn_input.setStorageMode(QgsFileWidget.GetFile)
        cn_row.addWidget(self.cn_input)
        cn_layout.addLayout(cn_row)
        
        cn_group.setLayout(cn_layout)
        layout.addWidget(cn_group)
        
        # Precipitation Data Group
        precip_group = QGroupBox("Dati Precipitazioni Estreme")
        precip_layout = QVBoxLayout()
        
        precip_label = QLabel("Cartella contenente i file a_Tr_*.tif e n_Tr_*.tif:")
        precip_layout.addWidget(precip_label)
        
        precip_row = QHBoxLayout()
        self.precip_folder = QgsFileWidget()
        self.precip_folder.setStorageMode(QgsFileWidget.GetDirectory)
        precip_row.addWidget(self.precip_folder)
        precip_layout.addLayout(precip_row)
        
        precip_group.setLayout(precip_layout)
        layout.addWidget(precip_group)
        
        # Bridge Data Group
        bridge_group = QGroupBox("Dati Ponti")
        bridge_layout = QVBoxLayout()
        
        # Excel file
        excel_row = QHBoxLayout()
        excel_row.addWidget(QLabel("File Excel Ponti:"))
        self.bridge_file = QgsFileWidget()
        self.bridge_file.setFilter("Excel Files (*.xlsx *.xls)")
        self.bridge_file.setStorageMode(QgsFileWidget.GetFile)
        excel_row.addWidget(self.bridge_file)
        self.btn_load_bridges = QPushButton("Carica")
        self.btn_load_bridges.setMaximumWidth(80)
        excel_row.addWidget(self.btn_load_bridges)
        bridge_layout.addLayout(excel_row)
        
        # Coordinate extraction options
        coord_label = QLabel("Estrazione coordinate:")
        bridge_layout.addWidget(coord_label)
        
        coord_row = QHBoxLayout()
        self.rb_from_file = QCheckBox("Dal file Excel (colonne: Latitude, Longitude)")
        self.rb_from_file.setChecked(True)
        coord_row.addWidget(self.rb_from_file)
        bridge_layout.addLayout(coord_row)
        
        manual_row = QHBoxLayout()
        self.rb_manual = QCheckBox("Manuale:")
        manual_row.addWidget(self.rb_manual)
        manual_row.addWidget(QLabel("Lon:"))
        self.outlet_lon = QDoubleSpinBox()
        self.outlet_lon.setRange(-180, 180)
        self.outlet_lon.setDecimals(6)
        self.outlet_lon.setValue(12.75287)
        self.outlet_lon.setEnabled(False)
        manual_row.addWidget(self.outlet_lon)
        manual_row.addWidget(QLabel("Lat:"))
        self.outlet_lat = QDoubleSpinBox()
        self.outlet_lat.setRange(-90, 90)
        self.outlet_lat.setDecimals(6)
        self.outlet_lat.setValue(41.942891)
        self.outlet_lat.setEnabled(False)
        manual_row.addWidget(self.outlet_lat)
        bridge_layout.addLayout(manual_row)
        
        # Preview table
        preview_label = QLabel("Anteprima ponti caricati:")
        bridge_layout.addWidget(preview_label)
        
        self.bridge_table = QTableWidget()
        self.bridge_table.setMaximumHeight(150)
        self.bridge_table.setColumnCount(5)
        self.bridge_table.setHorizontalHeaderLabels(
            ["Nome", "Altezza (m)", "Larghezza (m)", "Lon", "Lat"])
        bridge_layout.addWidget(self.bridge_table)
        
        bridge_group.setLayout(bridge_layout)
        layout.addWidget(bridge_group)
        
        layout.addStretch()
        widget.setLayout(layout)
        return widget
    
    def createParametersTab(self):
        """Create analysis parameters tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Return Periods Group
        tr_group = QGroupBox("Tempi di Ritorno")
        tr_layout = QVBoxLayout()
        
        tr_label = QLabel("Seleziona i tempi di ritorno da analizzare:")
        tr_layout.addWidget(tr_label)
        
        tr_checkboxes = QHBoxLayout()
        self.tr_checks = {}
        for tr in [2, 10, 25, 50, 100, 200, 500]:
            cb = QCheckBox(f"{tr} anni")
            cb.setChecked(True)
            tr_checkboxes.addWidget(cb)
            self.tr_checks[tr] = cb
        tr_layout.addLayout(tr_checkboxes)
        
        tr_group.setLayout(tr_layout)
        layout.addWidget(tr_group)
        
        # Bulking Factor Group
        bulk_group = QGroupBox("Fattore di Bulking")
        bulk_layout = QVBoxLayout()
        
        bulk_info = QLabel("Il fattore di bulking considera il trasporto solido.\n"
                          "Range tipico: 1.05 - 1.5")
        bulk_layout.addWidget(bulk_info)
        
        bulk_range = QHBoxLayout()
        bulk_range.addWidget(QLabel("Min:"))
        self.bulk_min = QDoubleSpinBox()
        self.bulk_min.setRange(1.0, 2.0)
        self.bulk_min.setDecimals(2)
        self.bulk_min.setSingleStep(0.05)
        self.bulk_min.setValue(1.05)
        bulk_range.addWidget(self.bulk_min)
        
        bulk_range.addWidget(QLabel("Max:"))
        self.bulk_max = QDoubleSpinBox()
        self.bulk_max.setRange(1.0, 2.0)
        self.bulk_max.setDecimals(2)
        self.bulk_max.setSingleStep(0.05)
        self.bulk_max.setValue(1.50)
        bulk_range.addWidget(self.bulk_max)
        
        bulk_range.addWidget(QLabel("N° campioni:"))
        self.bulk_samples = QSpinBox()
        self.bulk_samples.setRange(1, 100)
        self.bulk_samples.setValue(10)
        bulk_range.addWidget(self.bulk_samples)
        
        bulk_layout.addLayout(bulk_range)
        bulk_group.setLayout(bulk_layout)
        layout.addWidget(bulk_group)
        
        # Hydraulic Parameters Group
        hydr_group = QGroupBox("Parametri Idraulici")
        hydr_layout = QVBoxLayout()
        
        amin_row = QHBoxLayout()
        amin_row.addWidget(QLabel("Area minima bacino (km²):"))
        self.amin = QDoubleSpinBox()
        self.amin.setRange(0.1, 1000)
        self.amin.setDecimals(1)
        self.amin.setValue(2.0)
        amin_row.addWidget(self.amin)
        amin_row.addStretch()
        hydr_layout.addLayout(amin_row)
        
        reach_row = QHBoxLayout()
        reach_row.addWidget(QLabel("Lunghezza target (km):"))
        self.reach_length = QDoubleSpinBox()
        self.reach_length.setRange(1, 10000)
        self.reach_length.setDecimals(0)
        self.reach_length.setValue(1000)
        reach_row.addWidget(self.reach_length)
        reach_row.addStretch()
        hydr_layout.addLayout(reach_row)
        
        grad_row = QHBoxLayout()
        grad_row.addWidget(QLabel("Gradiente minimo:"))
        self.min_gradient = QDoubleSpinBox()
        self.min_gradient.setRange(0.00001, 1)
        self.min_gradient.setDecimals(6)
        self.min_gradient.setValue(0.0001)
        grad_row.addWidget(self.min_gradient)
        grad_row.addStretch()
        hydr_layout.addLayout(grad_row)
        
        hydr_group.setLayout(hydr_layout)
        layout.addWidget(hydr_group)
        
        layout.addStretch()
        widget.setLayout(layout)
        return widget
    
    def createOutputTab(self):
        """Create output settings tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Output folder
        out_group = QGroupBox("Cartella Output")
        out_layout = QVBoxLayout()
        
        folder_row = QHBoxLayout()
        folder_row.addWidget(QLabel("Cartella risultati:"))
        self.output_folder = QgsFileWidget()
        self.output_folder.setStorageMode(QgsFileWidget.GetDirectory)
        folder_row.addWidget(self.output_folder)
        out_layout.addLayout(folder_row)
        
        out_group.setLayout(out_layout)
        layout.addWidget(out_group)
        
        # Output options
        options_group = QGroupBox("Opzioni Output")
        options_layout = QVBoxLayout()
        
        self.save_plots = QCheckBox("Genera grafici (PNG)")
        self.save_plots.setChecked(True)
        options_layout.addWidget(self.save_plots)
        
        self.save_shapefile = QCheckBox("Salva risultati come Shapefile")
        self.save_shapefile.setChecked(True)
        options_layout.addWidget(self.save_shapefile)
        
        self.save_csv = QCheckBox("Salva statistiche come CSV")
        self.save_csv.setChecked(True)
        options_layout.addWidget(self.save_csv)
        
        self.add_to_map = QCheckBox("Aggiungi layer risultati a mappa QGIS")
        self.add_to_map.setChecked(True)
        options_layout.addWidget(self.add_to_map)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Prefix
        prefix_group = QGroupBox("Nome Analisi")
        prefix_layout = QHBoxLayout()
        prefix_layout.addWidget(QLabel("Prefisso file output:"))
        self.output_prefix = QLineEdit()
        self.output_prefix.setText("FloodAnalysis")
        prefix_layout.addWidget(self.output_prefix)
        prefix_group.setLayout(prefix_layout)
        layout.addWidget(prefix_group)
        
        layout.addStretch()
        widget.setLayout(layout)
        return widget
    
    def connectSignals(self):
        """Connect signals to slots"""
        self.btn_close.clicked.connect(self.reject)
        self.btn_run.clicked.connect(self.runAnalysis)
        self.btn_load_bridges.clicked.connect(self.loadBridgeData)
        
        # Coordinate input toggle
        self.rb_from_file.toggled.connect(self.toggleCoordinateInput)
        self.rb_manual.toggled.connect(self.toggleCoordinateInput)
    
    def setDefaultValues(self):
        """Set default file paths for Tevere case study"""
        # These are example paths - adjust to actual data location
        base_path = "/path/to/data"
        
        self.log("Plugin inizializzato. Configurare i percorsi dei dati.")
    
    def toggleCoordinateInput(self):
        """Toggle between file and manual coordinate input"""
        is_manual = self.rb_manual.isChecked()
        self.outlet_lon.setEnabled(is_manual)
        self.outlet_lat.setEnabled(is_manual)
    
    def loadBridgeData(self):
        """Load bridge data from Excel file"""
        file_path = self.bridge_file.filePath()
        
        if not file_path or not os.path.exists(file_path):
            QMessageBox.warning(self, "Errore", "Selezionare un file Excel valido")
            return
        
        try:
            # Read Excel file
            df = pd.read_excel(file_path)
            
            # Check required columns
            required_cols = ['Bridge', 'LowDeck']
            if not all(col in df.columns for col in required_cols):
                QMessageBox.warning(self, "Errore", 
                    f"Il file deve contenere le colonne: {', '.join(required_cols)}")
                return
            
            # Populate table
            self.bridge_table.setRowCount(len(df))
            
            for i, row in df.iterrows():
                self.bridge_table.setItem(i, 0, QTableWidgetItem(str(row.get('Bridge', ''))))
                self.bridge_table.setItem(i, 1, QTableWidgetItem(f"{row.get('LowDeck', 0):.2f}"))
                self.bridge_table.setItem(i, 2, QTableWidgetItem(f"{row.get('Width', 0):.2f}"))
                self.bridge_table.setItem(i, 3, QTableWidgetItem(f"{row.get('Longitude', 0):.6f}"))
                self.bridge_table.setItem(i, 4, QTableWidgetItem(f"{row.get('Latitude', 0):.6f}"))
            
            self.bridge_table.resizeColumnsToContents()
            
            # If coordinates are in file, use the first one as outlet
            if 'Latitude' in df.columns and 'Longitude' in df.columns:
                if self.rb_from_file.isChecked():
                    self.outlet_lat.setValue(df['Latitude'].iloc[0])
                    self.outlet_lon.setValue(df['Longitude'].iloc[0])
            
            self.log(f"Caricati {len(df)} ponti dal file Excel")
            
        except Exception as e:
            QMessageBox.critical(self, "Errore", f"Errore nel caricamento file:\n{str(e)}")
            self.log(f"ERRORE: {str(e)}")
    
    def log(self, message):
        """Add message to log"""
        self.log_text.append(message)
    
    def getSelectedReturnPeriods(self):
        """Get list of selected return periods"""
        return [tr for tr, cb in self.tr_checks.items() if cb.isChecked()]
    
    def validateInputs(self):
        """Validate all inputs"""
        errors = []
        
        # Check DEM files
        if not self.dem_input.filePath():
            errors.append("DEM non selezionato")
        if not self.fd_input.filePath():
            errors.append("Flow Direction non selezionato")
        if not self.acc_input.filePath():
            errors.append("Flow Accumulation non selezionato")
        
        # Check CN file
        if not self.cn_input.filePath():
            errors.append("File CN non selezionato")
        
        # Check precipitation folder
        if not self.precip_folder.filePath():
            errors.append("Cartella precipitazioni non selezionata")
        
        # Check bridge file
        if not self.bridge_file.filePath():
            errors.append("File ponti non selezionato")
        
        # Check output folder
        if not self.output_folder.filePath():
            errors.append("Cartella output non selezionata")
        
        # Check at least one return period selected
        if not self.getSelectedReturnPeriods():
            errors.append("Selezionare almeno un tempo di ritorno")
        
        if errors:
            QMessageBox.warning(self, "Validazione Input", 
                "\n".join(["Correggere i seguenti errori:"] + errors))
            return False
        
        return True
    
    def runAnalysis(self):
        """Run the flood risk analysis"""
        if not self.validateInputs():
            return
        
        self.log("\n" + "="*50)
        self.log("AVVIO ANALISI RISCHIO IDRAULICO")
        self.log("="*50)
        
        # Collect all parameters
        params = {
            'dem': self.dem_input.filePath(),
            'flow_dir': self.fd_input.filePath(),
            'accumulation': self.acc_input.filePath(),
            'cn': self.cn_input.filePath(),
            'precip_folder': self.precip_folder.filePath(),
            'bridge_file': self.bridge_file.filePath(),
            'outlet_lon': self.outlet_lon.value(),
            'outlet_lat': self.outlet_lat.value(),
            'return_periods': self.getSelectedReturnPeriods(),
            'bulk_min': self.bulk_min.value(),
            'bulk_max': self.bulk_max.value(),
            'bulk_samples': self.bulk_samples.value(),
            'amin_km2': self.amin.value(),
            'reach_length': self.reach_length.value(),
            'min_gradient': self.min_gradient.value(),
            'output_folder': self.output_folder.filePath(),
            'output_prefix': self.output_prefix.text(),
            'save_plots': self.save_plots.isChecked(),
            'save_shapefile': self.save_shapefile.isChecked(),
            'save_csv': self.save_csv.isChecked(),
            'add_to_map': self.add_to_map.isChecked()
        }
        
        self.log(f"Tempi di ritorno: {params['return_periods']}")
        self.log(f"Bulking range: {params['bulk_min']:.2f} - {params['bulk_max']:.2f}")
        self.log(f"Numero campioni: {params['bulk_samples']}")
        
        # Import and run the analysis
        try:
            from .flood_analysis_engine import FloodAnalysisEngine
            
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            
            engine = FloodAnalysisEngine(params, self.log, self.progress_bar)
            engine.run()
            
            self.log("\n" + "="*50)
            self.log("ANALISI COMPLETATA CON SUCCESSO!")
            self.log("="*50)
            
            QMessageBox.information(self, "Successo", 
                "Analisi completata! Controlla la cartella output per i risultati.")
            
        except Exception as e:
            self.log(f"\nERRORE FATALE: {str(e)}")
            QMessageBox.critical(self, "Errore", f"Errore durante l'analisi:\n{str(e)}")
        
        finally:
            self.progress_bar.setVisible(False)
