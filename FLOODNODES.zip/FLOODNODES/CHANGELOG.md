# Changelog - Flood Risk Analyzer

Tutte le modifiche significative a questo progetto saranno documentate in questo file.

Il formato è basato su [Keep a Changelog](https://keepachangelog.com/it/1.0.0/),
e questo progetto aderisce al [Semantic Versioning](https://semver.org/lang/it/).

---

## [1.0.0] - 2024-11-16

### Aggiunto
- **Interfaccia grafica completa** con 3 tabs organizzati (Input, Parametri, Output)
- **Analisi multi-periodo di ritorno**: Supporto per 2, 10, 25, 50, 100, 200, 500 anni
- **Import dati Excel**: Caricamento automatico ponti con estrazione coordinate
- **Fattore di bulking configurabile**: Range personalizzabile con distribuzione uniforme
- **Calcolo franchi idraulici**: Per ogni combinazione ponte/tempo di ritorno/bulking
- **Output georeferenziati**: Shapefile con risultati analisi
- **Grafici statistici**: 4 plot di sintesi con quantili e criticità
- **Export CSV**: Tabella completa tutti gli scenari analizzati
- **Integrazione Processing**: Algoritmo utilizzabile da Processing Toolbox
- **Log real-time**: Monitoraggio avanzamento analisi
- **Barra progresso**: Feedback visivo durante elaborazione
- **Dati esempio**: Caso studio Tevere con 5 ponti

### Caratteristiche Tecniche
- Metodo Curve Number (CN-SCS) per calcolo portate
- Formula Giandotti per tempo di corrivazione
- Supporto rating curves ponti
- Delimitazione automatica bacino idrografico
- Estrazione rete fluviale
- Analisi Monte Carlo con bulking factors
- Calcolo statistiche (Q10, Q50, Q90)
- Identificazione sezioni critiche (Franco ≤ 0)

### Documentazione
- README.md completo con guida utente
- INSTALL.md per installazione rapida
- File esempio con dati caso studio
- Documentazione inline nel codice
- Help integrato in Processing

### File Plugin
- `__init__.py`: Inizializzazione
- `metadata.txt`: Metadati plugin
- `flood_risk_analyzer.py`: Classe principale
- `flood_risk_dialog.py`: Interfaccia GUI
- `flood_analysis_engine.py`: Motore calcolo
- `processing_provider.py`: Provider Processing
- `processing_algorithm.py`: Algoritmo Processing
- `requirements.txt`: Dipendenze Python

---

## [Unreleased]

### Pianificato per v1.1.0
- [ ] Supporto curve di scala personalizzate
- [ ] Import dati ponti da Shapefile
- [ ] Calcolo indici di pericolosità
- [ ] Mappe di rischio interpolate
- [ ] Export report PDF automatico
- [ ] Supporto analisi multi-bacino
- [ ] Ottimizzazione performance DEM grandi
- [ ] Interfaccia multilingua (EN, IT)

### Idee Future
- [ ] Integrazione con database PostgreSQL/PostGIS
- [ ] Web service per analisi cloud
- [ ] Machine learning per previsioni
- [ ] Animazioni temporali rischio
- [ ] Supporto dati satellite in tempo reale
- [ ] App mobile companion

---

## Note di Versione

### Compatibilità
- **QGIS**: 3.0 o superiore
- **Python**: 3.7 o superiore
- **Sistema Operativo**: Windows, Linux, macOS

### Dipendenze Principali
- numpy >= 1.20.0
- pandas >= 1.3.0
- matplotlib >= 3.3.0
- topotoolbox >= 0.3.0

### Breaking Changes
Nessuno (prima release)

---

## Contributi

Grazie a tutti coloro che hanno contribuito a questo progetto!

### Core Team
- Your Name - Sviluppo iniziale e manutenzione

### Contributors
- (Lista contributori futuri)

---

## Licenza

GPL v3 - Vedi file LICENSE per dettagli

---

**Legenda**:
- `Aggiunto`: Nuove funzionalità
- `Modificato`: Cambiamenti a funzionalità esistenti
- `Deprecato`: Funzionalità presto rimosse
- `Rimosso`: Funzionalità rimosse
- `Corretto`: Bug fix
- `Sicurezza`: Vulnerabilità risolte

---

[1.0.0]: https://github.com/yourusername/flood-risk-analyzer/releases/tag/v1.0.0
[Unreleased]: https://github.com/yourusername/flood-risk-analyzer/compare/v1.0.0...HEAD
