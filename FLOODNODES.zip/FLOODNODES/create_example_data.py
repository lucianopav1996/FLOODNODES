# -*- coding: utf-8 -*-
"""
Script to create example bridge data Excel file
Tevere River case study - San Vittorino location
"""

import pandas as pd
import os

def create_example_bridge_data():
    """Create example bridge data for Tevere basin"""
    
    # Example bridge data with coordinates
    # These are hypothetical data for demonstration
    bridge_data = {
        'Bridge': [
            'Ponte_A',
            'Ponte_B', 
            'Ponte_C',
            'Ponte_D',
            'Ponte_E'
        ],
        'LowDeck': [
            155.5,  # Height of bridge deck bottom (m a.s.l.)
            158.2,
            162.8,
            151.3,
            165.4
        ],
        'Width': [
            25.0,   # Bridge width (m)
            18.5,
            30.0,
            22.0,
            28.5
        ],
        'Longitude': [
            12.75287,  # Coordinates in WGS84
            12.75420,
            12.75156,
            12.74998,
            12.75601
        ],
        'Latitude': [
            41.942891,
            41.943210,
            41.942456,
            41.941987,
            41.943567
        ],
        'Year_Built': [
            1965,
            1978,
            1985,
            1952,
            1992
        ],
        'Type': [
            'Concrete',
            'Steel',
            'Concrete',
            'Masonry',
            'Concrete'
        ],
        'Notes': [
            'Main crossing',
            'Secondary road',
            'Highway bridge',
            'Historic bridge',
            'New construction'
        ]
    }
    
    df = pd.DataFrame(bridge_data)
    
    # Create output directory
    output_dir = '/home/claude/flood_risk_analyzer/example_data'
    os.makedirs(output_dir, exist_ok=True)
    
    # Save to Excel
    output_file = os.path.join(output_dir, 'tevere_bridges_example.xlsx')
    df.to_excel(output_file, index=False, sheet_name='Bridges')
    
    print(f"File Excel creato: {output_file}")
    print(f"\nDati ponti generati:")
    print(df.to_string(index=False))
    
    # Also create a README
    readme_content = """
# Dati Esempio - Analisi Rischio Idraulico Tevere

## File Excel Ponti

Il file `tevere_bridges_example.xlsx` contiene dati di esempio per 5 ponti
sul fiume Tevere nella zona di San Vittorino.

### Colonne Required:
- **Bridge**: Nome identificativo del ponte
- **LowDeck**: Quota inferiore impalcato (m s.l.m.)
- **Width**: Larghezza ponte (m)
- **Longitude**: Longitudine WGS84 (°)
- **Latitude**: Latitudine WGS84 (°)

### Colonne Opzionali:
- Year_Built: Anno di costruzione
- Type: Tipologia strutturale
- Notes: Note aggiuntive

### Uso nel Plugin:

1. Caricare il file Excel tramite il pulsante "Sfoglia"
2. Selezionare "Dal file Excel" per l'estrazione coordinate
3. Il plugin utilizzerà automaticamente le coordinate per:
   - Localizzare i ponti sulla rete fluviale
   - Calcolare i franchi idraulici
   - Generare gli output georeferenziati

### Sezione di Chiusura:

La sezione di chiusura del bacino viene estratta automaticamente
dalla prima riga del file Excel:
- Longitudine: 12.75287°
- Latitudine: 41.942891°

Questo corrisponde all'area di San Vittorino sul Tevere.

## Dati Raster Necessari:

Per eseguire l'analisi completa, sono necessari:

1. **DEM** (Tevere_elv.tif)
2. **Flow Direction** (Tevere_dir.tif)  
3. **Flow Accumulation** (Tevere_upa.tif)
4. **Curve Number** (S2.tif o S3.tif)
5. **Precipitazioni Estreme**: 
   - Cartella contenente file a_Tr_*.tif e n_Tr_*.tif
   - Per tempi di ritorno: 2, 10, 25, 50, 100, 200, 500 anni

## Note:

I dati numerici in questo file sono **ESEMPI** per scopi dimostrativi.
Per analisi reali, utilizzare dati effettivi acquisiti da:
- Rilievi topografici
- Database cartografici ufficiali
- Progetti esistenti
"""
    
    readme_file = os.path.join(output_dir, 'README.md')
    with open(readme_file, 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print(f"\nREADME creato: {readme_file}")
    
    return output_file

if __name__ == '__main__':
    create_example_bridge_data()
