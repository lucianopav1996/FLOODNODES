# INSTALLAZIONE RAPIDA - Flood Risk Analyzer

## 🚀 Setup in 5 Minuti

### 1. Prerequisiti
```bash
# Installa le librerie Python necessarie
pip install pandas numpy matplotlib scipy shapely geopandas openpyxl topotoolbox
```

### 2. Installa il Plugin

#### Opzione A: Copia Diretta
```bash
# Copia la cartella del plugin nella directory QGIS

# Windows
xcopy /E /I flood_risk_analyzer "%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\flood_risk_analyzer"

# Linux/Mac
cp -r flood_risk_analyzer ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/
```

#### Opzione B: Da QGIS
1. Comprimere `flood_risk_analyzer` in ZIP
2. QGIS → Plugin → Gestisci e Installa Plugin → Installa da ZIP
3. Selezionare il file ZIP

### 3. Attiva il Plugin
1. Riavvia QGIS
2. Plugin → Gestisci e Installa Plugin
3. Cerca "Flood Risk Analyzer"
4. Spunta la checkbox per attivarlo

### 4. Test con Dati Esempio
1. Apri il plugin (icona toolbar o menu Plugin)
2. Carica i dati esempio dalla cartella `example_data/`
3. File Excel ponti: `tevere_bridges_example.xlsx`
4. Seleziona tempi di ritorno desiderati
5. Clicca "Esegui Analisi"

---

## 📁 Struttura File

```
flood_risk_analyzer/
├── __init__.py                    # Inizializzazione plugin
├── metadata.txt                   # Metadati plugin
├── flood_risk_analyzer.py         # Classe principale
├── flood_risk_dialog.py           # Interfaccia grafica
├── flood_analysis_engine.py       # Motore di calcolo
├── processing_provider.py         # Provider Processing
├── processing_algorithm.py        # Algoritmo Processing
├── create_example_data.py         # Script dati esempio
├── README.md                      # Documentazione completa
├── INSTALL.md                     # Questa guida
├── icon.png                       # Icona plugin
└── example_data/
    ├── tevere_bridges_example.xlsx
    └── README.md
```

---

## ✅ Verifica Installazione

### Test 1: Plugin Visibile
- Toolbar: Icona plugin presente
- Menu: Plugin → Flood Risk Analyzer visibile

### Test 2: Processing
1. Ctrl+Alt+T (Processing Toolbox)
2. Cerca "Flood Risk"
3. Algoritmo "Multi-Return Period..." presente

### Test 3: Esecuzione
1. Apri dialog plugin
2. Carica file esempio
3. Log mostra: "Plugin inizializzato..."

---

## 🔧 Risoluzione Problemi Comuni

### Plugin non appare dopo installazione
**Soluzione**: Riavviare QGIS completamente

### Errore import TopoToolbox
```bash
pip install --upgrade topotoolbox
```

### Errore import pandas/matplotlib
```bash
pip install pandas matplotlib scipy
```

### Plugin disabilitato automaticamente
1. Plugin → Gestisci Plugin
2. Mostra anche plugin non compatibili
3. Controlla log errori
4. Installa dipendenze mancanti

---

## 📚 Prossimi Passi

1. **Leggi README.md completo**: Guida dettagliata uso
2. **Prepara i tuoi dati**: Vedi sezione "Dati Input" in README
3. **Esegui analisi test**: Usa dati esempio forniti
4. **Analisi reale**: Configura con i tuoi dati GIS

---

## 💡 Tips

- **Prima volta**: Inizia con dati esempio per familiarizzare
- **Performance**: Riduci campioni bulking per test rapidi
- **Dati mancanti**: Controlla sempre il log per errori specifici
- **Backup**: Salva sempre configurazione parametri usati

---

## 📞 Supporto

- Leggi documentazione completa: README.md
- Controlla esempio: example_data/README.md
- Segnala bug: GitHub Issues

---

**Buona analisi!** 🌊📊
