# -*- coding: utf-8 -*-
"""
Test Script - Flood Risk Analyzer
Verifica installazione e dipendenze
"""

import sys
import importlib.util

def test_import(module_name, package_name=None):
    """Test if a module can be imported"""
    try:
        if package_name:
            __import__(package_name)
            print(f"✓ {module_name}: OK")
            return True
        else:
            __import__(module_name)
            print(f"✓ {module_name}: OK")
            return True
    except ImportError as e:
        print(f"✗ {module_name}: MANCANTE - {str(e)}")
        return False

def test_qgis_modules():
    """Test QGIS modules"""
    print("\n" + "="*60)
    print("TEST MODULI QGIS")
    print("="*60)
    
    qgis_modules = [
        ('qgis.core', 'qgis.core'),
        ('qgis.gui', 'qgis.gui'),
        ('qgis.PyQt.QtCore', 'qgis.PyQt'),
        ('qgis.PyQt.QtWidgets', None),
    ]
    
    results = []
    for module, package in qgis_modules:
        results.append(test_import(module, package))
    
    return all(results)

def test_python_libraries():
    """Test required Python libraries"""
    print("\n" + "="*60)
    print("TEST LIBRERIE PYTHON")
    print("="*60)
    
    libraries = [
        'numpy',
        'pandas',
        'matplotlib',
        'scipy',
        'shapely',
        'geopandas',
        'openpyxl',
    ]
    
    results = []
    for lib in libraries:
        results.append(test_import(lib))
    
    return all(results)

def test_topotoolbox():
    """Test TopoToolbox specifically"""
    print("\n" + "="*60)
    print("TEST TOPOTOOLBOX")
    print("="*60)
    
    try:
        import topotoolbox as tt
        print(f"✓ topotoolbox: OK")
        print(f"  Versione: {tt.__version__ if hasattr(tt, '__version__') else 'unknown'}")
        return True
    except ImportError as e:
        print(f"✗ topotoolbox: MANCANTE")
        print(f"  Installare con: pip install topotoolbox")
        print(f"  Errore: {str(e)}")
        return False

def test_plugin_files():
    """Test if plugin files exist"""
    print("\n" + "="*60)
    print("TEST FILE PLUGIN")
    print("="*60)
    
    import os
    plugin_dir = os.path.dirname(os.path.abspath(__file__))
    
    required_files = [
        '__init__.py',
        'metadata.txt',
        'flood_risk_analyzer.py',
        'flood_risk_dialog.py',
        'flood_analysis_engine.py',
        'processing_provider.py',
        'processing_algorithm.py',
    ]
    
    results = []
    for filename in required_files:
        filepath = os.path.join(plugin_dir, filename)
        exists = os.path.exists(filepath)
        
        if exists:
            print(f"✓ {filename}: OK")
        else:
            print(f"✗ {filename}: MANCANTE")
        
        results.append(exists)
    
    return all(results)

def test_example_data():
    """Test if example data exists"""
    print("\n" + "="*60)
    print("TEST DATI ESEMPIO")
    print("="*60)
    
    import os
    plugin_dir = os.path.dirname(os.path.abspath(__file__))
    example_dir = os.path.join(plugin_dir, 'example_data')
    
    if not os.path.exists(example_dir):
        print(f"✗ Cartella example_data: MANCANTE")
        return False
    
    print(f"✓ Cartella example_data: OK")
    
    excel_file = os.path.join(example_dir, 'tevere_bridges_example.xlsx')
    if os.path.exists(excel_file):
        print(f"✓ tevere_bridges_example.xlsx: OK")
        
        # Try to read Excel
        try:
            import pandas as pd
            df = pd.read_excel(excel_file)
            print(f"  Ponti nel file: {len(df)}")
            print(f"  Colonne: {', '.join(df.columns.tolist())}")
            return True
        except Exception as e:
            print(f"✗ Errore lettura Excel: {str(e)}")
            return False
    else:
        print(f"✗ tevere_bridges_example.xlsx: MANCANTE")
        return False

def print_summary(results):
    """Print test summary"""
    print("\n" + "="*60)
    print("RIEPILOGO TEST")
    print("="*60)
    
    total = len(results)
    passed = sum(results.values())
    failed = total - passed
    
    print(f"Test eseguiti: {total}")
    print(f"Superati: {passed}")
    print(f"Falliti: {failed}")
    
    if failed == 0:
        print("\n✓ TUTTI I TEST SUPERATI!")
        print("Il plugin è pronto per essere utilizzato in QGIS.")
    else:
        print("\n✗ ALCUNI TEST FALLITI")
        print("Installare le dipendenze mancanti prima di usare il plugin.")
        print("\nComandi utili:")
        print("  pip install -r requirements.txt")
        print("  pip install numpy pandas matplotlib scipy shapely geopandas openpyxl topotoolbox")
    
    return failed == 0

def main():
    """Main test function"""
    print("="*60)
    print("FLOOD RISK ANALYZER - TEST INSTALLAZIONE")
    print("="*60)
    print(f"Python version: {sys.version}")
    print(f"Python executable: {sys.executable}")
    
    # Run all tests
    results = {
        'Plugin Files': test_plugin_files(),
        'Python Libraries': test_python_libraries(),
        'TopoToolbox': test_topotoolbox(),
        'Example Data': test_example_data(),
    }
    
    # Note: QGIS modules test only if running within QGIS
    if 'qgis' in sys.modules or any('qgis' in k for k in sys.path):
        results['QGIS Modules'] = test_qgis_modules()
    else:
        print("\n" + "="*60)
        print("TEST MODULI QGIS: SALTATO")
        print("="*60)
        print("ℹ Test QGIS disponibile solo eseguendo da console QGIS")
        print("  Per testare da QGIS Python Console:")
        print("  >>> import sys")
        print("  >>> sys.path.append('/path/to/plugin/folder')")
        print("  >>> import test_installation")
        print("  >>> test_installation.main()")
    
    # Print summary
    success = print_summary(results)
    
    return 0 if success else 1

if __name__ == '__main__':
    sys.exit(main())
