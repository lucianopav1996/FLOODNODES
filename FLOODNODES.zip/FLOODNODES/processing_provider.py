# -*- coding: utf-8 -*-
"""
Processing Provider for Flood Risk Analyzer
Integrates the analysis into QGIS Processing Framework
"""

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
import os


class FloodRiskProvider(QgsProcessingProvider):
    """Processing provider for flood risk analysis algorithms"""
    
    def __init__(self):
        super().__init__()
    
    def id(self):
        """Unique provider ID"""
        return 'floodrisk'
    
    def name(self):
        """Human-readable provider name"""
        return 'Flood Risk Analysis'
    
    def icon(self):
        """Provider icon"""
        return QIcon(os.path.join(os.path.dirname(__file__), 'icon.png'))
    
    def loadAlgorithms(self):
        """Load all algorithms"""
        # Import and add algorithms
        from .processing_algorithm import FloodRiskAlgorithm
        self.addAlgorithm(FloodRiskAlgorithm())
