# DATI ESEMPIO - PLUGIN FLOOD RISK ANALYZER

## File Excel Ponti - Struttura Corretta

Il file Excel deve contenere UN FOGLIO PER OGNI PONTE con le RATING CURVES (h-Q).

### Struttura:
- Riga 1-2: Coordinate UTM (x, y)
- Riga 3-5: Quote ponte (upper deck, low deck, h_fondo)
- Riga 7+: Rating curve (h, Q)

### Esempio: Tor_sapienza_rating_curves.xlsx
29 ponti con rating curves complete

### Coordinate:
- Input: UTM Zone 33N
- Output: WGS84 (conversione automatica)

### Sezione Chiusura Tor Sapienza:
- Lon: 12.58636°
- Lat: 41.91786°
