# -*- coding: utf-8 -*-
"""
FLOODNODES - QGIS Plugin
Hydrological Flood Risk Analysis for Watersheds ≤150 km²
"""

def classFactory(iface):
    """Load FLOODNODES class from file floodnodes.
    
    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .floodnodes import FLOODNODES
    return FLOODNODES(iface)
