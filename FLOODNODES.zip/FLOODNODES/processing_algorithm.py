# -*- coding: utf-8 -*-
"""
Processing Algorithm for Flood Risk Analysis
Can be run from QGIS Processing Toolbox
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingOutputVectorLayer,
    QgsProcessingOutputFile,
    QgsProcessingException
)
from qgis.PyQt.QtCore import QCoreApplication
import processing


class FloodRiskAlgorithm(QgsProcessingAlgorithm):
    """Processing algorithm for flood risk analysis"""
    
    # Parameter names
    INPUT_DEM = 'INPUT_DEM'
    INPUT_FLOW_DIR = 'INPUT_FLOW_DIR'
    INPUT_ACCUMULATION = 'INPUT_ACCUMULATION'
    INPUT_CN = 'INPUT_CN'
    INPUT_PRECIP_FOLDER = 'INPUT_PRECIP_FOLDER'
    INPUT_BRIDGE_FILE = 'INPUT_BRIDGE_FILE'
    OUTLET_LON = 'OUTLET_LON'
    OUTLET_LAT = 'OUTLET_LAT'
    RETURN_PERIODS = 'RETURN_PERIODS'
    BULK_MIN = 'BULK_MIN'
    BULK_MAX = 'BULK_MAX'
    BULK_SAMPLES = 'BULK_SAMPLES'
    AMIN_KM2 = 'AMIN_KM2'
    OUTPUT_FOLDER = 'OUTPUT_FOLDER'
    OUTPUT_PREFIX = 'OUTPUT_PREFIX'
    
    def tr(self, string):
        """Returns a translatable string"""
        return QCoreApplication.translate('Processing', string)
    
    def createInstance(self):
        """Returns a new instance of the algorithm"""
        return FloodRiskAlgorithm()
    
    def name(self):
        """Algorithm name"""
        return 'floodnodes'
    
    def displayName(self):
        """Algorithm display name"""
        return self.tr('FLOODNODES')
    
    def group(self):
        """Algorithm group"""
        return self.tr('FLOODNODES')
    
    def groupId(self):
        """Algorithm group ID"""
        return 'floodnodes'
    
    def shortHelpString(self):
        """Short help text"""
        return self.tr("""
        FLOODNODES - Analisi idrologica del rischio di alluvione
        Validato per bacini idrografici ≤150 km²
        
        Questo algoritmo utilizza il Metodo Razionale e SCS Curve Number 
        con formulazione Hawkins (2010) per calcolare le portate di picco 
        e i franchi idraulici dei ponti.
        
        Tempi di ritorno: 2, 10, 25, 50, 100, 200, 500 anni
        
        Input richiesti:
        - DEM (Digital Elevation Model)
        - Flow Direction
        - Flow Accumulation  
        - CN (Massima capacità di assorbimento del suolo)
        - Cartella con dati precipitazioni estreme
        - File Excel con dati ponti
        - Coordinate sezione di chiusura
        
        Output generati:
        - Shapefile risultati analisi ponti
        - Shapefile bacino di drenaggio
        - Shapefile reticolo idrografico
        - Grafici statistici
        - File CSV con dati completi
        
        Finanziato da: PNRR - CUP: D43C22003030002
        """)
    
    def initAlgorithm(self, config=None):
        """Define algorithm parameters"""
        
        # DEM inputs
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_DEM,
                self.tr('DEM (Digital Elevation Model)'),
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_FLOW_DIR,
                self.tr('Flow Direction'),
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_ACCUMULATION,
                self.tr('Flow Accumulation'),
                optional=False
            )
        )
        
        # CN input
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_CN,
                self.tr('Curve Number (CN)'),
                optional=False
            )
        )
        
        # Precipitation folder
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_PRECIP_FOLDER,
                self.tr('Cartella Precipitazioni Estreme'),
                behavior=QgsProcessingParameterFile.Folder,
                optional=False
            )
        )
        
        # Bridge data file
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_BRIDGE_FILE,
                self.tr('File Excel Ponti'),
                extension='xlsx',
                optional=False
            )
        )
        
        # Outlet coordinates
        self.addParameter(
            QgsProcessingParameterNumber(
                self.OUTLET_LON,
                self.tr('Longitudine Sezione Chiusura'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=12.75287
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.OUTLET_LAT,
                self.tr('Latitudine Sezione Chiusura'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=41.942891
            )
        )
        
        # Return periods (comma-separated)
        self.addParameter(
            QgsProcessingParameterString(
                self.RETURN_PERIODS,
                self.tr('Tempi di Ritorno (separati da virgola)'),
                defaultValue='2,10,25,50,100,200,500'
            )
        )
        
        # Bulking factor parameters
        self.addParameter(
            QgsProcessingParameterNumber(
                self.BULK_MIN,
                self.tr('Bulking Factor Minimo'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=1.05,
                minValue=1.0,
                maxValue=3.0
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.BULK_MAX,
                self.tr('Bulking Factor Massimo'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=1.50,
                minValue=1.0,
                maxValue=3.0
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.BULK_SAMPLES,
                self.tr('Numero Campioni Bulking'),
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=10,
                minValue=1,
                maxValue=100
            )
        )
        
        # Minimum drainage area
        self.addParameter(
            QgsProcessingParameterNumber(
                self.AMIN_KM2,
                self.tr('Area Minima Bacino (km²)'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2.0,
                minValue=0.1
            )
        )
        
        # Output folder
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_FOLDER,
                self.tr('Cartella Output')
            )
        )
        
        # Output prefix
        self.addParameter(
            QgsProcessingParameterString(
                self.OUTPUT_PREFIX,
                self.tr('Prefisso File Output'),
                defaultValue='FloodAnalysis'
            )
        )
    
    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm"""
        
        feedback.pushInfo("="*50)
        feedback.pushInfo("FLOOD RISK ANALYSIS - Processing Algorithm")
        feedback.pushInfo("="*50)
        
        # Get parameters
        dem_layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        fd_layer = self.parameterAsRasterLayer(parameters, self.INPUT_FLOW_DIR, context)
        acc_layer = self.parameterAsRasterLayer(parameters, self.INPUT_ACCUMULATION, context)
        cn_layer = self.parameterAsRasterLayer(parameters, self.INPUT_CN, context)
        
        precip_folder = self.parameterAsFile(parameters, self.INPUT_PRECIP_FOLDER, context)
        bridge_file = self.parameterAsFile(parameters, self.INPUT_BRIDGE_FILE, context)
        
        outlet_lon = self.parameterAsDouble(parameters, self.OUTLET_LON, context)
        outlet_lat = self.parameterAsDouble(parameters, self.OUTLET_LAT, context)
        
        tr_string = self.parameterAsString(parameters, self.RETURN_PERIODS, context)
        return_periods = [int(x.strip()) for x in tr_string.split(',')]
        
        bulk_min = self.parameterAsDouble(parameters, self.BULK_MIN, context)
        bulk_max = self.parameterAsDouble(parameters, self.BULK_MAX, context)
        bulk_samples = self.parameterAsInt(parameters, self.BULK_SAMPLES, context)
        
        amin_km2 = self.parameterAsDouble(parameters, self.AMIN_KM2, context)
        
        output_folder = self.parameterAsFile(parameters, self.OUTPUT_FOLDER, context)
        output_prefix = self.parameterAsString(parameters, self.OUTPUT_PREFIX, context)
        
        # Build parameters dictionary
        analysis_params = {
            'dem': dem_layer.source(),
            'flow_dir': fd_layer.source(),
            'accumulation': acc_layer.source(),
            'cn': cn_layer.source(),
            'precip_folder': precip_folder,
            'bridge_file': bridge_file,
            'outlet_lon': outlet_lon,
            'outlet_lat': outlet_lat,
            'return_periods': return_periods,
            'bulk_min': bulk_min,
            'bulk_max': bulk_max,
            'bulk_samples': bulk_samples,
            'amin_km2': amin_km2,
            'reach_length': 1000,
            'min_gradient': 0.0001,
            'output_folder': output_folder,
            'output_prefix': output_prefix,
            'save_plots': True,
            'save_shapefile': True,
            'save_csv': True,
            'add_to_map': True
        }
        
        feedback.pushInfo(f"\nParametri analisi:")
        feedback.pushInfo(f"  - Tempi di ritorno: {return_periods}")
        feedback.pushInfo(f"  - Bulking: {bulk_min:.2f} - {bulk_max:.2f} ({bulk_samples} campioni)")
        feedback.pushInfo(f"  - Area minima: {amin_km2} km²")
        feedback.pushInfo(f"  - Sezione: Lon={outlet_lon:.6f}, Lat={outlet_lat:.6f}")
        
        # Run analysis
        try:
            from .flood_analysis_engine import FloodAnalysisEngine
            
            def log_callback(msg):
                feedback.pushInfo(msg)
            
            class ProgressAdapter:
                def __init__(self, feedback):
                    self.feedback = feedback
                    self.current_value = 0
                
                def setValue(self, value):
                    self.current_value = value
                    self.feedback.setProgress(value)
                
                def setVisible(self, visible):
                    pass
            
            progress = ProgressAdapter(feedback)
            
            engine = FloodAnalysisEngine(analysis_params, log_callback, progress)
            engine.run()
            
            feedback.pushInfo("\n" + "="*50)
            feedback.pushInfo("ANALISI COMPLETATA CON SUCCESSO!")
            feedback.pushInfo("="*50)
            
            # Return outputs
            results = {
                'OUTPUT_FOLDER': output_folder
            }
            
            return results
            
        except Exception as e:
            feedback.reportError(f"ERRORE durante l'analisi: {str(e)}", True)
            raise QgsProcessingException(str(e))
