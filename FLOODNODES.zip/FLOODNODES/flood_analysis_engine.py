# -*- coding: utf-8 -*-
"""
Flood Analysis Engine - VERSIONE CORRETTA FINALE
Fix: Resample delle griglie di precipitazione prima del crop
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

# CRITICAL: Aggiungi path OSGeo4W per TopoToolbox
osgeo_path = r"C:\OSGeo4W\apps\Python312\Lib\site-packages"
if osgeo_path not in sys.path:
    sys.path.insert(0, osgeo_path)

# Import funzioni da file locali
from .plot_utils_functions import (
    load_bridge_data,
    resample_grid,
)

# TopoToolbox - Import globale
tt = None
try:
    import topotoolbox as tt
except ImportError:
    pass

from scipy.interpolate import interp1d, RegularGridInterpolator
from scipy.stats import pearsonr
from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, 
                      QgsPointXY, QgsField, QgsVectorFileWriter, QgsProject)
from qgis.PyQt.QtCore import QVariant


class FloodAnalysisEngine:
    """Engine che esegue l'analisi delle alluvioni - COPIA ESATTA dello script funzionante"""
    
    def __init__(self, params, log_callback, progress_callback):
        # Import TopoToolbox
        global tt
        if tt is None:
            try:
                import topotoolbox as tt
                self.log("✓ TopoToolbox caricato")
            except ImportError as e:
                raise ImportError(f"TopoToolbox non trovato: {e}\n" + 
                                "Verifica che startup.py sia configurato correttamente")
        
        self.tt = tt
        self.params = params
        self.log = log_callback
        self.progress = progress_callback
        self.output_dir = Path(params['output_folder'])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.return_periods = params['return_periods']
        self.bulking_factors = np.linspace(params['bulk_min'], params['bulk_max'], params['bulk_samples'])
    
    def run(self):
        """Esegue analisi - COPIA ESATTA dello script originale con resample corretto"""
        try:
            self.log("="*80)
            self.log(f"ANALISI FLOOD RISK: {self.params['output_prefix']}")
            self.log("="*80)
            
            # 1. LOAD DEM
            self.progress.setValue(5)
            self.log("\n1. Loading and processing DEM data...")
            
            dem = self.tt.read_tif(str(self.params['dem']))
            dem.z = dem.z.astype(np.float64)
            self.log(f"   DEM loaded: {dem.shape} pixels, cellsize = {dem.cellsize}")
            
            fd = self.tt.FlowObject(dem)
            a = fd.flow_accumulation()
            self.log(f"   Flow accumulation range: {np.nanmin(a.z):.0f} - {np.nanmax(a.z):.0f}")
            
            # 2. DELINEATE BASIN
            self.progress.setValue(15)
            self.log("\n2. Delineating drainage basin...")
            
            outlet_coord = [self.params['outlet_lon'], self.params['outlet_lat']]
            outlet_col = int((outlet_coord[0] - dem.bounds.left) / dem.cellsize)
            outlet_row = int((dem.bounds.top - outlet_coord[1]) / dem.cellsize)
            
            self.log(f"   Outlet: {outlet_coord}, grid: row={outlet_row}, col={outlet_col}")
            
            outlet_grid = dem.duplicate_with_new_data(np.zeros(dem.shape, dtype=bool))
            outlet_grid.z[outlet_row, outlet_col] = True
            outlet_indices = np.where(outlet_grid.z.ravel(order='F'))[0]
            
            db = fd.drainagebasins(outlet_indices)
            mask = db.duplicate_with_new_data((db.z == 1).astype(bool))
            
            basin_rows, basin_cols = np.where(mask.z)
            min_row, max_row = np.min(basin_rows), np.max(basin_rows)
            min_col, max_col = np.min(basin_cols), np.max(basin_cols)
            
            buffer_cells = 10
            min_row = max(0, min_row - buffer_cells)
            max_row = min(dem.rows - 1, max_row + buffer_cells)
            min_col = max(0, min_col - buffer_cells)
            max_col = min(dem.columns - 1, max_col + buffer_cells)
            
            left = dem.bounds.left + min_col * dem.cellsize
            right = dem.bounds.left + (max_col + 1) * dem.cellsize
            top = dem.bounds.top - min_row * dem.cellsize
            bottom = dem.bounds.top - (max_row + 1) * dem.cellsize
            
            self.log(f"   Basin extent: rows {min_row}-{max_row}, cols {min_col}-{max_col}")
            
            # 3. CROP TO BASIN
            self.progress.setValue(25)
            self.log("\n3. Cropping to basin extent...")
            
            # Crop datasets to basin bounds
            dem_crop = dem.crop(left, right, top, bottom, 'coordinate')
            dem_crop.z = np.ascontiguousarray(dem_crop.z)
            
            fd_crop = tt.FlowObject(dem_crop)
            a_crop = a.crop(left, right, top, bottom, 'coordinate')
            mask_crop = mask.crop(left, right, top, bottom, 'coordinate')
            
            # Calculate basin area
            lat_center = (dem_crop.bounds.top + dem_crop.bounds.bottom) / 2
            km_per_deg_lon = 111.32 * np.cos(np.radians(lat_center))
            km_per_deg_lat = 111.32
            cell_area_km2 = (dem_crop.cellsize * km_per_deg_lon) * (dem_crop.cellsize * km_per_deg_lat)
            basin_area = np.sum(mask_crop.z) * cell_area_km2
            
            self.log(f"   Cropped DEM: {dem_crop.shape}")
            
            # 4. LOAD BRIDGES AND STREAM
            self.progress.setValue(35)
            self.log("\n4. Loading bridges and extracting stream network...")
            
            bridges, lat_all, lon_all = load_bridge_data(str(self.params['bridge_file']))
            self.log(f"   Loaded {len(bridges)} bridges")
            print("\n4. Extracting river network...")

            # Crop drainage basin
            db_crop = db.crop(left, right, top, bottom, 'coordinate')
            basin_mask = (db_crop.z == 1)
 
            dem_crop.z[db_crop.z != 1] = np.nan
            fd_crop = tt.FlowObject(dem_crop)
            a_crop = fd_crop.flow_accumulation()
            a_crop.z[db_crop.z != 1] = np.nan
 
            amin_cells = 0.50 / cell_area_km2
            w_stream = a_crop.duplicate_with_new_data(a_crop.z >= amin_cells)
            s = tt.StreamObject(fd_crop, threshold=amin_cells, units='pixels')
            s_connected = s.klargestconncomps(k=1)
            s_connected.to_shapefile(self.output_dir / f"river_network.shp")
            
            self.log(f"   Stream network nodes: {len(s_connected.stream)}")
            
            # 4.8 BRIDGE SNAPPING - EXACT COPY
            self.log("   4.8 Snapping bridges to main stream network...")
            
            MAX_SNAP_DISTANCE_CELLS = 20
            MIN_DRAINAGE_AREA_KM2 = 10.0
            
            stream_pixel_rows, stream_pixel_cols = np.where(w_stream.z)
            stream_drainage_areas = a_crop.z[stream_pixel_rows, stream_pixel_cols] * cell_area_km2
            
            self.log(f"   Found {len(stream_pixel_rows)} stream pixels")
            self.log(f"   Drainage area range: {np.nanmin(stream_drainage_areas):.1f} - {np.nanmax(stream_drainage_areas):.1f} km²")
            
            main_stream_mask = stream_drainage_areas >= MIN_DRAINAGE_AREA_KM2
            main_stream_rows = stream_pixel_rows[main_stream_mask]
            main_stream_cols = stream_pixel_cols[main_stream_mask]
            main_stream_areas = stream_drainage_areas[main_stream_mask]
            
            self.log(f"   Main stream pixels (area ≥ {MIN_DRAINAGE_AREA_KM2} km²): {len(main_stream_rows)}")
            
            if len(main_stream_rows) == 0:
                self.log("   WARNING: No main stream pixels found, reducing threshold...")
                MIN_DRAINAGE_AREA_KM2 = 5.0
                main_stream_mask = stream_drainage_areas >= MIN_DRAINAGE_AREA_KM2
                main_stream_rows = stream_pixel_rows[main_stream_mask]
                main_stream_cols = stream_pixel_cols[main_stream_mask]
                main_stream_areas = stream_drainage_areas[main_stream_mask]
                self.log(f"   Main stream pixels (area ≥ {MIN_DRAINAGE_AREA_KM2} km²): {len(main_stream_rows)}")
            
            breaknodes = []
            valid_bridges = []
            snapping_info = []
            breaknode_lons = []  
            breaknode_lats = []
            
            for i, bridge in enumerate(bridges):
                bridge_lon = bridge['lon']
                bridge_lat = bridge['lat']
                
                bridge_col = int((bridge_lon - dem_crop.bounds.left) / dem_crop.cellsize)
                bridge_row = int((dem_crop.bounds.top - bridge_lat) / dem_crop.cellsize)
                
                if not (0 <= bridge_row < dem_crop.rows and 0 <= bridge_col < dem_crop.columns):
                    self.log(f"   ✗ {bridge['name']}: outside bounds")
                    continue
                
                distances = np.sqrt((main_stream_rows - bridge_row)**2 + (main_stream_cols - bridge_col)**2)
                within_distance = distances <= MAX_SNAP_DISTANCE_CELLS
                
                if not np.any(within_distance):
                    self.log(f"   ✗ {bridge['name']}: no main stream within {MAX_SNAP_DISTANCE_CELLS} cells")
                    continue
                
                candidate_distances = distances[within_distance]
                candidate_areas = main_stream_areas[within_distance]
                candidate_rows = main_stream_rows[within_distance]
                candidate_cols = main_stream_cols[within_distance]
                
                normalized_areas = candidate_areas / np.max(candidate_areas)
                normalized_distances = candidate_distances / np.max(candidate_distances)
                scores = normalized_areas - 0.3 * normalized_distances
                
                best_idx = np.argmax(scores)
                
                closest_stream_row = candidate_rows[best_idx]
                closest_stream_col = candidate_cols[best_idx]
                snap_distance = candidate_distances[best_idx]
                snap_area = candidate_areas[best_idx]
                
                # Converti in indice lineare (row-major order)
                closest_linear_idx = closest_stream_row * dem_crop.columns + closest_stream_col
                
                if w_stream.z[closest_stream_row, closest_stream_col]:
                    distance_m = snap_distance * cell_area_km2**0.5 * 1000
                    
                    breaknodes.append(closest_linear_idx)
                    valid_bridges.append(bridge)
                    
                    stream_lon = dem_crop.bounds.left + closest_stream_col * dem_crop.cellsize
                    stream_lat = dem_crop.bounds.top - closest_stream_row * dem_crop.cellsize
                    breaknode_lons.append(stream_lon)
                    breaknode_lats.append(stream_lat)
                    
                    snapping_info.append({
                        'name': bridge['name'],
                        'distance_m': distance_m,
                        'drainage_area_km2': snap_area,
                        'snap_score': scores[best_idx]
                    })
                    
                    self.log(f"   ✓ {bridge['name']}: snapped at {distance_m:.1f}m, drainage area {snap_area:.1f} km²")
                else:
                    self.log(f"   ✗ {bridge['name']}: snapping verification failed")
            
            breaknodes = np.array(breaknodes, dtype=np.int32)
            self.log(f"   Successfully snapped {len(valid_bridges)} bridges")
            
            if len(valid_bridges) == 0:
                raise ValueError("No bridges could be snapped to the stream network!")
            
            # =================================================================
            # VERIFICA QUALITÀ SNAPPING
            # =================================================================

            print("\n   Verifying snapping quality...")

            # Calcola l'area di drenaggio per ogni ponte snappato
            ponte_drainage_areas = []
            for i, bridge in enumerate(valid_bridges):
                node_linear_idx = breaknodes[i]
                node_row = node_linear_idx // dem_crop.columns  # Correzione: row-major order
                node_col = node_linear_idx % dem_crop.columns
                
                drainage_area = a_crop.z[node_row, node_col] * cell_area_km2
                ponte_drainage_areas.append(drainage_area)

            ponte_drainage_areas = np.array(ponte_drainage_areas)

            print(f"   Snapped bridge drainage areas: {np.min(ponte_drainage_areas):.1f} - {np.max(ponte_drainage_areas):.1f} km²")

            # Identifica ponti potenzialmente problematici
            problematic_bridges = []
            for i, bridge in enumerate(valid_bridges):
                if ponte_drainage_areas[i] < MIN_DRAINAGE_AREA_KM2:
                    problematic_bridges.append({
                        'name': bridge['name'],
                        'area': ponte_drainage_areas[i],
                        'index': i
                    })

            if problematic_bridges:
                print(f"\n   WARNING: {len(problematic_bridges)} bridges may still be on tributaries:")
                for pb in problematic_bridges:
                    print(f"   - {pb['name']}: {pb['area']:.1f} km² (< {MIN_DRAINAGE_AREA_KM2} km²)")
            else:
                print("   ✓ All bridges successfully snapped to main stream network")

            # =================================================================
            # OPZIONE: RE-SNAPPING PER PONTI PROBLEMATICI
            # =================================================================

            if problematic_bridges and len(main_stream_rows) > 0:
                print("\n   Attempting re-snapping for problematic bridges...")
                
                for pb in problematic_bridges:
                    bridge_idx = pb['index']
                    bridge = valid_bridges[bridge_idx]
                    
                    print(f"   Re-snapping {bridge['name']}...")
                    
                    # Coordinate originali del ponte
                    bridge_lon = bridge['lon']
                    bridge_lat = bridge['lat']
                    bridge_col = int((bridge_lon - dem_crop.bounds.left) / dem_crop.cellsize)
                    bridge_row = int((dem_crop.bounds.top - bridge_lat) / dem_crop.cellsize)
                    
                    # Aumenta la distanza di ricerca
                    extended_distance = MAX_SNAP_DISTANCE_CELLS * 2
                    distances = np.sqrt((main_stream_rows - bridge_row)**2 + (main_stream_cols - bridge_col)**2)
                    
                    # Trova il pixel con area di drenaggio massima entro la distanza estesa
                    within_extended_distance = distances <= extended_distance
                    
                    if np.any(within_extended_distance):
                        candidate_areas = main_stream_areas[within_extended_distance]
                        candidate_distances = distances[within_extended_distance]
                        candidate_rows = main_stream_rows[within_extended_distance]
                        candidate_cols = main_stream_cols[within_extended_distance]
                        
                        # Priorità assoluta all'area di drenaggio
                        best_area_idx = np.argmax(candidate_areas)
                        
                        new_stream_row = candidate_rows[best_area_idx]
                        new_stream_col = candidate_cols[best_area_idx]
                        new_distance = candidate_distances[best_area_idx]
                        new_area = candidate_areas[best_area_idx]
                        
                        # Aggiorna breaknode
                        new_linear_idx = new_stream_row * dem_crop.columns + new_stream_col
                        breaknodes[bridge_idx] = new_linear_idx
                        
                        # Aggiorna coordinate
                        new_stream_lon = dem_crop.bounds.left + new_stream_col * dem_crop.cellsize
                        new_stream_lat = dem_crop.bounds.top - new_stream_row * dem_crop.cellsize
                        breaknode_lons[bridge_idx] = new_stream_lon
                        breaknode_lats[bridge_idx] = new_stream_lat
                        
                        distance_m = new_distance * cell_area_km2**0.5 * 1000
                        print(f"   ✓ Re-snapped {bridge['name']}: {distance_m:.1f}m, drainage area {new_area:.1f} km²")
                    else:
                        print(f"   ✗ Could not re-snap {bridge['name']}")

            print(f"   Final snapping complete: {len(valid_bridges)} bridges")

            
            # 5. LOAD CN - EXACT COPY WITH RESAMPLE
            self.progress.setValue(45)
            self.log("\n5. Loading SCS curve number data...")
            
            try:
                s_cn_orig = self.tt.read_tif(str(self.params['cn']))
                s_cn_orig.z[s_cn_orig.z > 10000] = np.nan
                self.log(f"   CN range: {np.nanmin(s_cn_orig.z):.1f} - {np.nanmax(s_cn_orig.z):.1f}")
                
                # CRITICAL: Resample to DEM resolution BEFORE cropping
                try:
                    s_cn_resample = resample_grid(s_cn_orig, dem)
                except:
                    self.log("   Using interpolation for CN resampling...")
                    target_lons = np.linspace(dem.bounds.left, dem.bounds.right, dem.columns)
                    target_lats = np.linspace(dem.bounds.top, dem.bounds.bottom, dem.rows)
                    target_lon_grid, target_lat_grid = np.meshgrid(target_lons, target_lats)
                    
                    orig_lons = np.linspace(s_cn_orig.bounds.left, s_cn_orig.bounds.right, s_cn_orig.columns)
                    orig_lats = np.linspace(s_cn_orig.bounds.top, s_cn_orig.bounds.bottom, s_cn_orig.rows)
                    
                    interp_cn = RegularGridInterpolator((orig_lats, orig_lons), s_cn_orig.z, 
                                                      method='linear', bounds_error=False, fill_value=np.nan)
                    s_cn_interpolated = interp_cn((target_lat_grid, target_lon_grid))
                    s_cn_resample = dem.duplicate_with_new_data(s_cn_interpolated)
                
                # NOW crop to basin bounds
                s_cn_grid = s_cn_resample.crop(left, right, top, bottom, 'coordinate')
                
                # Force exact dimensions to match dem_crop
                if s_cn_grid.shape != dem_crop.shape:
                    self.log(f"   Forcing CN dimensions from {s_cn_grid.shape} to {dem_crop.shape}")
                    target_rows, target_cols = dem_crop.shape
                    if s_cn_grid.z.shape[0] < target_rows:
                        rows_to_add = target_rows - s_cn_grid.z.shape[0]
                        mean_val = np.nanmean(s_cn_grid.z[-1, :]) if not np.all(np.isnan(s_cn_grid.z[-1, :])) else 50.0
                        s_cn_grid.z = np.vstack([s_cn_grid.z, np.full((rows_to_add, s_cn_grid.z.shape[1]), mean_val)])
                    elif s_cn_grid.z.shape[0] > target_rows:
                        s_cn_grid.z = s_cn_grid.z[:target_rows, :]
                    
                    if s_cn_grid.z.shape[1] < target_cols:
                        cols_to_add = target_cols - s_cn_grid.z.shape[1]
                        mean_val = np.nanmean(s_cn_grid.z[:, -1]) if not np.all(np.isnan(s_cn_grid.z[:, -1])) else 50.0
                        s_cn_grid.z = np.hstack([s_cn_grid.z, np.full((s_cn_grid.z.shape[0], cols_to_add), mean_val)])
                    elif s_cn_grid.z.shape[1] > target_cols:
                        s_cn_grid.z = s_cn_grid.z[:, :target_cols]
                
            except:
                self.log("   Creating fallback CN grid...")
                s_cn_grid = dem_crop.duplicate_with_new_data(np.full(dem_crop.shape, 50.0))
            
            self.log(f"   CN grid: {s_cn_grid.shape}, range: {np.nanmin(s_cn_grid.z):.1f}-{np.nanmax(s_cn_grid.z):.1f}")
            
            # 6. CALCULATE PARAMETERS - USE CONSISTENT FORMULA
            self.progress.setValue(55)
            self.log("\n6. Calculating hydrological parameters...")
            
            n_bridges = len(valid_bridges)
            tau_b = np.zeros(n_bridges)
            l_asta = np.zeros(n_bridges)
            ab = np.zeros(n_bridges)
            hm = np.zeros(n_bridges)
            
            for i, bridge in enumerate(valid_bridges):
                node_linear_idx = breaknodes[i]
                # Use row-major formula consistently
                node_row = node_linear_idx // dem_crop.columns
                node_col = node_linear_idx % dem_crop.columns
                
                try:
                    basin = fd_crop.drainagebasins(breaknodes[[i]])
                    basin_mask = (basin.z == 1)
                    
                    ab[i] = np.sum(basin_mask) * cell_area_km2
                    l_asta[i] = ab[i]**0.6
                    
                    basin_elev = dem_crop.z[basin_mask]
                    basin_elev = basin_elev[~np.isnan(basin_elev)]
                    
                    if len(basin_elev) > 0:
                        outlet_elev = dem_crop.z[node_row, node_col]
                        if not np.isnan(outlet_elev):
                            hm[i] = max(1.0, np.mean(basin_elev) - outlet_elev)
                        else:
                            hm[i] = 100.0
                    else:
                        hm[i] = 100.0
                    
                    tau_b[i] = (4 * np.sqrt(ab[i]) + 1.5 * l_asta[i]) / (0.8 * np.sqrt(hm[i]))
                    tau_b[i] = max(0.5, min(tau_b[i], 48.0))
                    
                except:
                    tau_b[i] = 2.0
                    l_asta[i] = 5.0
                    ab[i] = 10.0
                    hm[i] = 100.0
            
            self.log(f"   Tau: {np.min(tau_b):.2f}-{np.max(tau_b):.2f} h")
            self.log(f"   Areas: {np.min(ab):.1f}-{np.max(ab):.1f} km²")
            
            # 7. MULTI-TR ANALYSIS - WITH PROPER GRID LOADING
            self.progress.setValue(65)
            self.log("\n7. Multi-return period analysis...")
            
            # PRE-LOAD AND RESAMPLE ALL PRECIPITATION GRIDS
            precip_grids = {}
            for tr in self.return_periods:
                a_file = Path(self.params['precip_folder']) / f"a_Tr_{tr}_wgs84.tif"
                n_file = Path(self.params['precip_folder']) / f"n_Tr_{tr}_wgs84.tif"
                
                if not (a_file.exists() and n_file.exists()):
                    self.log(f"   Tr={tr}: Files not found, skipping...")
                    continue
                
                try:
                    self.log(f"   Loading precipitation grids for Tr={tr}...")
                    
                    # Load grids
                    a_tr_orig = self.tt.read_tif(str(a_file))
                    n_tr_orig = self.tt.read_tif(str(n_file))
                    
                    # Clean values
                    a_tr_orig.z[a_tr_orig.z > 500] = np.nan
                    n_tr_orig.z[n_tr_orig.z > 2] = np.nan
                    
                    self.log(f"     Original sizes - a_tr: {a_tr_orig.shape}, n_tr: {n_tr_orig.shape}")
                    
                    # CRITICAL: Resample to DEM resolution BEFORE cropping
                    self.log(f"     Resampling to DEM resolution...")
                    
                    try:
                        a_tr_resampled = resample_grid(a_tr_orig, dem)
                        n_tr_resampled = resample_grid(n_tr_orig, dem)
                    except:
                        self.log(f"     Using interpolation method...")
                        target_lons = np.linspace(dem.bounds.left, dem.bounds.right, dem.columns)
                        target_lats = np.linspace(dem.bounds.top, dem.bounds.bottom, dem.rows)
                        target_lon_grid, target_lat_grid = np.meshgrid(target_lons, target_lats)
                        
                        orig_lons_a = np.linspace(a_tr_orig.bounds.left, a_tr_orig.bounds.right, a_tr_orig.columns)
                        orig_lats_a = np.linspace(a_tr_orig.bounds.top, a_tr_orig.bounds.bottom, a_tr_orig.rows)
                        interp_a = RegularGridInterpolator((orig_lats_a, orig_lons_a), a_tr_orig.z,
                                                          method='linear', bounds_error=False, fill_value=np.nan)
                        a_tr_interpolated = interp_a((target_lat_grid, target_lon_grid))
                        a_tr_resampled = dem.duplicate_with_new_data(a_tr_interpolated)
                        
                        orig_lons_n = np.linspace(n_tr_orig.bounds.left, n_tr_orig.bounds.right, n_tr_orig.columns)
                        orig_lats_n = np.linspace(n_tr_orig.bounds.top, n_tr_orig.bounds.bottom, n_tr_orig.rows)
                        interp_n = RegularGridInterpolator((orig_lats_n, orig_lons_n), n_tr_orig.z,
                                                          method='linear', bounds_error=False, fill_value=np.nan)
                        n_tr_interpolated = interp_n((target_lat_grid, target_lon_grid))
                        n_tr_resampled = dem.duplicate_with_new_data(n_tr_interpolated)
                    
                    self.log(f"     Resampled sizes - a_tr: {a_tr_resampled.shape}, n_tr: {n_tr_resampled.shape}")
                    
                    # NOW crop to basin bounds
                    self.log(f"     Cropping to basin bounds...")
                    a_tr_grid = a_tr_resampled.crop(left, right, top, bottom, 'coordinate')
                    n_tr_grid = n_tr_resampled.crop(left, right, top, bottom, 'coordinate')
                    
                    self.log(f"     Cropped sizes - a_tr: {a_tr_grid.shape}, n_tr: {n_tr_grid.shape}")
                    
                    # Force exact dimensions to match dem_crop
                    if a_tr_grid.shape != dem_crop.shape:
                        self.log(f"     Forcing a_tr dimensions...")
                        target_rows, target_cols = dem_crop.shape
                        current_rows, current_cols = a_tr_grid.shape
                        
                        if current_rows < target_rows:
                            rows_to_add = target_rows - current_rows
                            last_rows = np.tile(a_tr_grid.z[-1:, :], (rows_to_add, 1))
                            a_tr_grid.z = np.vstack([a_tr_grid.z, last_rows])
                        elif current_rows > target_rows:
                            a_tr_grid.z = a_tr_grid.z[:target_rows, :]
                        
                        if a_tr_grid.z.shape[1] < target_cols:
                            cols_to_add = target_cols - a_tr_grid.z.shape[1]
                            last_cols = np.tile(a_tr_grid.z[:, -1:], (1, cols_to_add))
                            a_tr_grid.z = np.hstack([a_tr_grid.z, last_cols])
                        elif a_tr_grid.z.shape[1] > target_cols:
                            a_tr_grid.z = a_tr_grid.z[:, :target_cols]
                    
                    if n_tr_grid.shape != dem_crop.shape:
                        self.log(f"     Forcing n_tr dimensions...")
                        target_rows, target_cols = dem_crop.shape
                        current_rows, current_cols = n_tr_grid.shape
                        
                        if current_rows < target_rows:
                            rows_to_add = target_rows - current_rows
                            last_rows = np.tile(n_tr_grid.z[-1:, :], (rows_to_add, 1))
                            n_tr_grid.z = np.vstack([n_tr_grid.z, last_rows])
                        elif current_rows > target_rows:
                            n_tr_grid.z = n_tr_grid.z[:target_rows, :]
                        
                        if n_tr_grid.z.shape[1] < target_cols:
                            cols_to_add = target_cols - n_tr_grid.z.shape[1]
                            last_cols = np.tile(n_tr_grid.z[:, -1:], (1, cols_to_add))
                            n_tr_grid.z = np.hstack([n_tr_grid.z, last_cols])
                        elif n_tr_grid.z.shape[1] > target_cols:
                            n_tr_grid.z = n_tr_grid.z[:, :target_cols]
                    
                    # Store in dictionary
                    precip_grids[tr] = {'a_tr': a_tr_grid, 'n_tr': n_tr_grid}
                    
                    self.log(f"     ✓ Tr={tr} loaded: final shapes a_tr={a_tr_grid.shape}, n_tr={n_tr_grid.shape}, dem_crop={dem_crop.shape}")
                    
                except Exception as e:
                    self.log(f"     ✗ Error loading Tr={tr}: {e}")
                    import traceback
                    self.log(traceback.format_exc())
                    precip_grids[tr] = None
            
            self.log(f"   Successfully loaded {len([tr for tr in self.return_periods if tr in precip_grids and precip_grids[tr] is not None])} return periods")
            
            # Process each return period
            all_results = []
            
            for tr in self.return_periods:
                if tr not in precip_grids or precip_grids[tr] is None:
                    continue
                    
                self.log(f"\n   Tr = {tr} years...")
                
                a_tr = precip_grids[tr]['a_tr']
                n_tr = precip_grids[tr]['n_tr']
                
                p_t = np.zeros(n_bridges)
                h_t = np.zeros(n_bridges)
                s_mean = np.zeros(n_bridges)
                
                for i, bridge in enumerate(valid_bridges):
                    try:
                        basin = fd_crop.drainagebasins(np.array([breaknodes[i]]))
                        basin_mask = (basin.z == 1)
                        
                        if not np.any(basin_mask):
                            self.log(f"     WARNING: Empty basin for {bridge['name']}")
                            p_t[i], h_t[i], s_mean[i] = 5.0, 10.0, 50.0
                            continue
                        
                        # Extract precipitation values
                        a_vals = a_tr.z[basin_mask]
                        n_vals = n_tr.z[basin_mask]
                        valid = ~(np.isnan(a_vals) | np.isnan(n_vals))
                        
                        if np.any(valid):
                            h_t[i] = np.mean(a_vals[valid] * (tau_b[i] ** n_vals[valid]))
                        else:
                            h_t[i] = 10.0
                            self.log(f"     No valid precipitation data for {bridge['name']}")
                        
                        # Extract S parameter
                        s_vals = s_cn_grid.z[basin_mask]
                        s_vals = s_vals[~(np.isinf(s_vals) | np.isnan(s_vals))]
                        s_mean[i] = np.mean(s_vals) if len(s_vals) > 0 else 50.0
                        
                        # Calculate runoff using SCS method
                        ia = 0.05 * s_mean[i]
                        p_t[i] = ((h_t[i] - ia)**2) / (h_t[i] - ia + s_mean[i]) if h_t[i] > ia else 0.02
                        if np.isnan(p_t[i]) or p_t[i] <= 0:
                            p_t[i] = 0.02
                    
                    except Exception as e:
                        self.log(f"     ERROR for {bridge['name']}: {str(e)}")
                        p_t[i], h_t[i], s_mean[i] = 5.0, 10.0, 50.0
                
                # Log statistics for this return period
                self.log(f"     P_t range: {np.min(p_t):.2f}-{np.max(p_t):.2f} mm")
                self.log(f"     H_t range: {np.min(h_t):.2f}-{np.max(h_t):.2f} mm")
                
                q_base = 0.278 * p_t * ab / tau_b
                
                for bf in self.bulking_factors:
                    q_bulked = q_base * bf
                    
                    for i, bridge in enumerate(valid_bridges):
                        rating = bridge['rating_curve']
                        
                        if len(rating) > 1:
                            h_vals, q_vals = rating[:, 0], rating[:, 1]
                            if q_bulked[i] <= q_vals[-1]:
                                h_water = float(interp1d(q_vals, h_vals, fill_value='extrapolate')(q_bulked[i]))
                            else:
                                slope = (h_vals[-1] - h_vals[-2]) / (q_vals[-1] - q_vals[-2])
                                h_water = h_vals[-1] + slope * (q_bulked[i] - q_vals[-1])
                        else:
                            h_water = bridge['h_fondo'] + 1.0
                        
                        franco = bridge['low_deck'] - h_water
                        
                        all_results.append({
                            'Bridge_Name': bridge['name'],
                            'Bridge_ID': i + 1,
                            'X': breaknode_lons[i],
                            'Y': breaknode_lats[i],
                            'Return_Period': tr,
                            'Bulking_Factor': bf,
                            'Q_base': q_base[i],
                            'Q_bulked': q_bulked[i],
                            'Water_Level': h_water,
                            'LowDeck': bridge['low_deck'],
                            'UpperDeck': bridge.get('upper_deck', bridge['low_deck'] + 2.0),
                            'Franco_bulked': franco,
                            'Critical': franco <= 0,
                            'Longitude': bridge['lon'],
                            'Latitude': bridge['lat'],
                            'Area_km2': ab[i],
                            'Tau_b': tau_b[i],
                            'P_t': p_t[i],
                            'H_intensity': h_t[i],
                            'S_mean': s_mean[i]
                        })
            
            # 8. SAVE
            self.progress.setValue(85)
            self.log("\n8. Saving results...")
            
            df_results = pd.DataFrame(all_results)
            self.log(f"   Total: {len(df_results)} scenarios")
            
            # Check if rainfall calculation worked
            if len(df_results) > 0:
                p_t_values = df_results['P_t'].unique()
                if len(p_t_values) == 1 and p_t_values[0] == 5.0:
                    self.log("\n   ⚠️ WARNING: All P_t values are 5.0 - rainfall calculation may have failed!")
                    self.log("   Check that precipitation grids have correct resolution and coverage")
                else:
                    self.log(f"   ✓ P_t range: {df_results['P_t'].min():.2f} - {df_results['P_t'].max():.2f} mm")
                    self.log(f"   ✓ H_intensity range: {df_results['H_intensity'].min():.2f} - {df_results['H_intensity'].max():.2f} mm")
            
            # Save CSV
            csv_path = self.output_dir / f"{self.params['output_prefix']}_results.csv"
            df_results.to_csv(csv_path, index=False)
            self.log(f"   ✓ Saved: {csv_path}")
            
            # Create shapefile
            self._create_shapefile(df_results)
            
            # Generate plots
            self.progress.setValue(95)
            self.log("\n9. Generating plots...")
            self._generate_plots(df_results)
            
            self.progress.setValue(100)
            self.log("\n✓ Analysis completed successfully!")
            
            return True
            
        except Exception as e:
            self.log(f"\n✗ ERROR: {str(e)}")
            import traceback
            self.log(traceback.format_exc())
            return False
    
    def _create_shapefile(self, df_results):
        """Create 7 separate shapefiles (one per return period) - EXACT COPY from original code"""
        try:
            self.log("\n   Exporting results by return period (7 separate files)...")
            
            return_periods = sorted(df_results['Return_Period'].unique())
            self.log(f"   Creating {len(return_periods)} files (one per return period)")
            
            # Export one file per return period
            for tr in return_periods:
                self.log(f"   Processing return period {tr} years...")
                
                # Filter data for this return period
                tr_data = df_results[df_results['Return_Period'] == tr]
                
                # Create aggregated results per bridge (averaging over bulking factors)
                tr_results = []
                
                for bridge_name in tr_data['Bridge_Name'].unique():
                    bridge_data = tr_data[tr_data['Bridge_Name'] == bridge_name]
                    
                    if len(bridge_data) > 0:
                        # Take first record for basic information
                        first_record = bridge_data.iloc[0]
                        
                        # Aggregate over different bulking factors for this return period
                        result = {
                            'X': first_record['X'],
                            'Y': first_record['Y'],
                            'ID': int(first_record['Bridge_ID']),
                            'Nome': bridge_name,
                            'Return_Period': int(tr),
                            'Q_median': float(bridge_data['Q_bulked'].median()),
                            'Q_min': float(bridge_data['Q_bulked'].min()),
                            'Q_max': float(bridge_data['Q_bulked'].max()),
                            'LowDeck': float(first_record['LowDeck']),
                            'UpperDeck': float(first_record['UpperDeck']),
                            'Franco_median': float(bridge_data['Franco_bulked'].median()),
                            'Franco_min': float(bridge_data['Franco_bulked'].min()),
                            'Franco_max': float(bridge_data['Franco_bulked'].max()),
                            'Critical_cases': int(len(bridge_data[bridge_data['Franco_bulked'] <= 0])),
                            'Total_BF': int(len(bridge_data)),
                            'Critical_pct': float((bridge_data['Franco_bulked'] <= 0).mean() * 100),
                            'Area_km2': float(first_record['Area_km2']),
                            'P_t_median': float(bridge_data['P_t'].median()),
                            'Tau_b': float(first_record['Tau_b']),
                            'BF_range': f"{bridge_data['Bulking_Factor'].min():.2f}-{bridge_data['Bulking_Factor'].max():.2f}"
                        }
                        
                        tr_results.append(result)
                
                # Create shapefile for this return period
                if len(tr_results) > 0:
                    layer = QgsVectorLayer("Point?crs=EPSG:4326", f"Tr{tr}y", "memory")
                    provider = layer.dataProvider()
                    
                    # Add fields - EXACT MATCH with original
                    fields = []
                    fields.append(QgsField("ID", QVariant.Int))
                    fields.append(QgsField("Nome", QVariant.String, len=50))
                    fields.append(QgsField("Return_Per", QVariant.Int))
                    fields.append(QgsField("Q_median", QVariant.Double))
                    fields.append(QgsField("Q_min", QVariant.Double))
                    fields.append(QgsField("Q_max", QVariant.Double))
                    fields.append(QgsField("LowDeck", QVariant.Double))
                    fields.append(QgsField("UpperDeck", QVariant.Double))
                    fields.append(QgsField("Franco_med", QVariant.Double))
                    fields.append(QgsField("Franco_min", QVariant.Double))
                    fields.append(QgsField("Franco_max", QVariant.Double))
                    fields.append(QgsField("Crit_cases", QVariant.Int))
                    fields.append(QgsField("Total_BF", QVariant.Int))
                    fields.append(QgsField("Crit_pct", QVariant.Double))
                    fields.append(QgsField("Area_km2", QVariant.Double))
                    fields.append(QgsField("P_t_med", QVariant.Double))
                    fields.append(QgsField("Tau_b", QVariant.Double))
                    fields.append(QgsField("BF_range", QVariant.String, len=20))
                    
                    provider.addAttributes(fields)
                    layer.updateFields()
                    
                    # Add features
                    for result in tr_results:
                        feature = QgsFeature()
                        feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(result['X'], result['Y'])))
                        feature.setAttributes([
                            result['ID'],
                            result['Nome'],
                            result['Return_Period'],
                            result['Q_median'],
                            result['Q_min'],
                            result['Q_max'],
                            result['LowDeck'],
                            result['UpperDeck'],
                            result['Franco_median'],
                            result['Franco_min'],
                            result['Franco_max'],
                            result['Critical_cases'],
                            result['Total_BF'],
                            result['Critical_pct'],
                            result['Area_km2'],
                            result['P_t_median'],
                            result['Tau_b'],
                            result['BF_range']
                        ])
                        provider.addFeature(feature)
                    
                    # Save to file - EXACT NAMING from original
                    shp_path = str(self.output_dir / f"ponti_Tr{tr}y_{self.params['output_prefix']}_CN2.shp")
                    QgsVectorFileWriter.writeAsVectorFormat(layer, shp_path, "UTF-8", layer.crs(), "ESRI Shapefile")
                    self.log(f"     ✓ Saved {len(tr_results)} bridges to: {shp_path}")
                    
                    # Add to QGIS
                    QgsProject.instance().addMapLayer(layer)
                else:
                    self.log(f"     ✗ No data for return period {tr}")
            
            self.log(f"\n   Export completed: {len(return_periods)} files created")
            
        except Exception as e:
            self.log(f"   Error creating shapefiles: {e}")
            import traceback
            self.log(traceback.format_exc())
    
    def _generate_plots(self, df_results):
        """Generate 4 detailed analysis plots - EXACT COPY from original code"""
        try:
            self.log("\n   Creating detailed analysis plots (4 plots)...")
            
            # Get return periods and bridges
            return_periods = sorted(df_results['Return_Period'].unique())
            bridge_names = df_results['Bridge_Name'].unique()
            
            # Get first bridge for detailed analysis
            first_bridge = bridge_names[0]
            bridge_data = df_results[df_results['Bridge_Name'] == first_bridge].copy()
            
            # Create 2x2 plot grid
            fig = plt.figure(figsize=(16, 12))
            
            # =================================================================
            # PLOT 1: Franco vs Tempo di Ritorno - Ponte Singolo
            # =================================================================
            plt.subplot(2, 2, 1)
            
            unique_bfs = sorted(bridge_data['Bulking_Factor'].unique())
            colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', 
                      '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
            
            for i, bf in enumerate(unique_bfs):
                bf_data = bridge_data[bridge_data['Bulking_Factor'] == bf].copy()
                bf_data = bf_data.sort_values('Return_Period')
                
                if len(bf_data) > 0:
                    plt.plot(bf_data['Return_Period'], bf_data['Franco_bulked'], 
                            'o-', color=colors[i % len(colors)], linewidth=2.5, markersize=6,
                            label=f'BF = {bf:.2f}')
            
            plt.axhline(y=0, color='red', linestyle='--', linewidth=2, alpha=0.8, label='Franco = 0 (CRITICO)')
            plt.axhline(y=1.5, color='orange', linestyle='--', linewidth=2, alpha=0.8, label='Franco = 1.5m')
            
            plt.xlabel('Tempo di Ritorno (anni)', fontsize=12)
            plt.ylabel('Franco Idraulico (m)', fontsize=12)
            plt.title(f'{first_bridge} - Franco vs Tempo di Ritorno', fontsize=14, fontweight='bold')
            plt.grid(True, alpha=0.3)
            plt.legend(fontsize=9, loc='best')
            plt.xscale('log')
            plt.xticks(return_periods, [str(x) for x in return_periods])
            
            # =================================================================
            # PLOT 2: Franco vs Tempo di Ritorno - TUTTI I PONTI con QUANTILI
            # =================================================================
            plt.subplot(2, 2, 2)
            
            # Calculate quantiles for each return period
            quantile_data = []
            for tr in sorted(return_periods):
                tr_data = df_results[df_results['Return_Period'] == tr]['Franco_bulked']
                if len(tr_data) > 0:
                    quantile_data.append({
                        'Return_Period': tr,
                        'q10': tr_data.quantile(0.10),
                        'q50': tr_data.quantile(0.50),  # Median
                        'q90': tr_data.quantile(0.90),
                        'min': tr_data.min(),
                        'max': tr_data.max()
                    })
            
            quantile_df = pd.DataFrame(quantile_data)
            
            # Plot Q10-Q90 band
            plt.fill_between(quantile_df['Return_Period'], 
                            quantile_df['q10'], quantile_df['q90'],
                            color='lightblue', alpha=0.6, label='Banda Q10-Q90')
            
            # Plot median (black line)
            plt.plot(quantile_df['Return_Period'], quantile_df['q50'], 
                     'o-', color='black', linewidth=3, markersize=8, label='Mediana (Q50)')
            
            # Plot min-max range
            plt.fill_between(quantile_df['Return_Period'], 
                            quantile_df['min'], quantile_df['max'],
                            color='gray', alpha=0.2, label='Range Min-Max')
            
            # Reference lines
            plt.axhline(y=0, color='red', linestyle='--', linewidth=2, alpha=0.8, label='Franco = 0 (CRITICO)')
            plt.axhline(y=1.5, color='orange', linestyle='--', linewidth=2, alpha=0.8, label='Franco = 1.5m')
            
            plt.xlabel('Tempo di Ritorno (anni)', fontsize=12)
            plt.ylabel('Franco Idraulico (m)', fontsize=12)
            plt.title('Tutti i Ponti - Quantili Franco vs Tempo di Ritorno', fontsize=14, fontweight='bold')
            plt.grid(True, alpha=0.3)
            plt.legend(fontsize=10, loc='best')
            plt.xscale('log')
            plt.xticks(return_periods, [str(x) for x in return_periods])
            
            # =================================================================
            # PLOT 3: Franco vs Portata (log-log)
            # =================================================================
            plt.subplot(2, 2, 3)
            
            import matplotlib.cm as cm
            import matplotlib.colors as colors_module
            
            # Normalize colors for return period
            norm = colors_module.Normalize(vmin=min(return_periods), vmax=max(return_periods))
            cmap = cm.get_cmap('OrRd')
            
            for tr in sorted(return_periods):
                tr_data = df_results[df_results['Return_Period'] == tr]
                if len(tr_data) > 0:
                    plt.scatter(tr_data['Q_bulked'], tr_data['Franco_bulked'], 
                               c=cmap(norm(tr)), alpha=0.6, s=30, label=f'{tr} anni')
            
            plt.axhline(y=0, color='red', linestyle='--', linewidth=2, alpha=0.8)
            plt.axhline(y=1.5, color='orange', linestyle='--', linewidth=1, alpha=0.6)
            
            plt.xlabel('Portata Q_bulked (m³/s)', fontsize=12)
            plt.ylabel('Franco Idraulico (m)', fontsize=12)
            plt.title('Franco vs Portata (con bulking)', fontsize=14, fontweight='bold')
            plt.grid(True, alpha=0.3)
            plt.xscale('log')
            plt.legend(fontsize=9, bbox_to_anchor=(1.05, 1), loc='upper left')
            
            # Correlation
            valid_mask = (df_results['Q_bulked'] > 0) & (~np.isnan(df_results['Franco_bulked']))
            if np.any(valid_mask):
                corr_data = df_results[valid_mask]
                corr_pearson_q, p_pearson_q = pearsonr(np.log(corr_data['Q_bulked']), 
                                                       corr_data['Franco_bulked'])
                plt.text(0.05, 0.95, f'r = {corr_pearson_q:.3f}', 
                         transform=plt.gca().transAxes, fontsize=11, verticalalignment='top',
                         bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
            
            # =================================================================
            # PLOT 4: Percentuale Sezioni Critiche per Tempo di Ritorno
            # =================================================================
            plt.subplot(2, 2, 4)
            
            # Calculate percentage of critical cases for each return period
            critical_stats = []
            for tr in sorted(return_periods):
                tr_data = df_results[df_results['Return_Period'] == tr]
                if len(tr_data) > 0:
                    critical_count = len(tr_data[tr_data['Franco_bulked'] <= 0])
                    total_count = len(tr_data)
                    critical_pct = (critical_count / total_count) * 100
                    
                    critical_stats.append({
                        'Return_Period': tr,
                        'Critical_Pct': critical_pct,
                        'Critical_Count': critical_count,
                        'Total_Count': total_count
                    })
            
            critical_df = pd.DataFrame(critical_stats)
            
            # Bar plot with line overlay
            fig_ax = plt.gca()
            
            # Bars
            bars = fig_ax.bar(critical_df['Return_Period'], critical_df['Critical_Pct'], 
                             color='darkred', alpha=0.7, edgecolor='black', linewidth=1.5,
                             label='% Sezioni Critiche')
            
            # Line plot overlay
            fig_ax.plot(critical_df['Return_Period'], critical_df['Critical_Pct'], 
                       'o-', color='red', linewidth=3, markersize=8, 
                       markerfacecolor='white', markeredgecolor='red', markeredgewidth=2)
            
            # Add values on bars
            for i, (bar, row) in enumerate(zip(bars, critical_df.itertuples())):
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height + 1,
                         f'{height:.1f}%\n({row.Critical_Count}/{row.Total_Count})',
                         ha='center', va='bottom', fontsize=10, fontweight='bold')
            
            # Reference lines
            plt.axhline(y=50, color='orange', linestyle='--', linewidth=2, alpha=0.8, 
                        label='50% Sezioni Critiche')
            plt.axhline(y=100, color='red', linestyle='--', linewidth=2, alpha=0.8, 
                        label='100% Sezioni Critiche')
            
            plt.xlabel('Tempo di Ritorno (anni)', fontsize=12)
            plt.ylabel('Sezioni Critiche (%)', fontsize=12)
            plt.title('Percentuale Sezioni Critiche per Tempo di Ritorno\n(Scala di Bacino)', 
                      fontsize=14, fontweight='bold')
            plt.grid(True, alpha=0.3, axis='y')
            plt.legend(fontsize=10, loc='upper left')
            
            # Log scale for x
            plt.xscale('log')
            plt.xticks(return_periods, [str(x) for x in return_periods])
            
            # Y limits for better visualization
            plt.ylim(0, max(105, critical_df['Critical_Pct'].max() + 10))
            
            # Add additional information
            total_bridges = len(df_results['Bridge_Name'].unique())
            total_scenarios = len(df_results)
            
            info_text = f"Ponti analizzati: {total_bridges}\n"
            info_text += f"Scenari totali: {total_scenarios}\n"
            info_text += f"Bulking factors: {self.params['bulk_samples']}"
            
            plt.text(0.98, 0.02, info_text, transform=fig_ax.transAxes, 
                     fontsize=9, verticalalignment='bottom', horizontalalignment='right',
                     bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))
            
            plt.tight_layout()
            
            # Save plot
            plot_path = self.output_dir / f"simplified_analysis_CN2_{self.params['output_prefix']}.png"
            plt.savefig(plot_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            self.log(f"   ✓ Plot saved: {plot_path}")
            
            # Print statistics
            self._print_statistics(df_results, quantile_df, critical_df)
            
        except Exception as e:
            self.log(f"   Error generating plots: {e}")
            import traceback
            self.log(traceback.format_exc())
    
    def _print_statistics(self, df_results, quantile_df, critical_df):
        """Print detailed statistics - EXACT COPY from original code"""
        try:
            self.log("\n" + "="*80)
            self.log("STATISTICHE DETTAGLIATE")
            self.log("="*80)
            
            # Quantile statistics
            self.log("\nQUANTILI PER TEMPO DI RITORNO:")
            self.log("-" * 50)
            for _, row in quantile_df.iterrows():
                tr = int(row['Return_Period'])
                self.log(f"Tr = {tr:3d} anni: Q10 = {row['q10']:5.2f}m, Q50 = {row['q50']:5.2f}m, Q90 = {row['q90']:5.2f}m")
            
            # Critical cases
            self.log("\nCASI CRITICI PER TEMPO DI RITORNO:")
            self.log("-" * 50)
            for _, row in critical_df.iterrows():
                tr = int(row['Return_Period'])
                self.log(f"Tr = {tr:3d} anni: {row['Critical_Pct']:4.1f}% ({row['Critical_Count']:2d}/{row['Total_Count']:2d} casi)")
            
            # Bridge statistics
            self.log("\nSTATISTICHE PER PONTE (Franco Idraulico):")
            self.log("-" * 50)
            bridge_names = sorted(df_results['Bridge_Name'].unique())
            for bridge in bridge_names:
                bridge_data_full = df_results[df_results['Bridge_Name'] == bridge]
                critical_cases = len(bridge_data_full[bridge_data_full['Franco_bulked'] <= 0])
                median_franco = bridge_data_full['Franco_bulked'].median()
                q10_franco = bridge_data_full['Franco_bulked'].quantile(0.10)
                q90_franco = bridge_data_full['Franco_bulked'].quantile(0.90)
                total_cases = len(bridge_data_full)
                low_deck = bridge_data_full['LowDeck'].iloc[0]
                
                self.log(f"{bridge:20s}: Altezza = {low_deck:4.1f}m, "
                          f"Franco [Q10,Q50,Q90] = [{q10_franco:5.2f},{median_franco:5.2f},{q90_franco:5.2f}]m, "
                          f"Critici = {critical_cases:2d}/{total_cases:2d} ({critical_cases/total_cases*100:4.1f}%)")
            
        except Exception as e:
            self.log(f"   Error printing statistics: {e}")
