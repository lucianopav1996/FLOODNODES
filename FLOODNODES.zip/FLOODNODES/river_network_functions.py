"""
River Network Extraction and Analysis Functions
Python translation of MATLAB TopoToolbox functions for flood risk analysis
EXACT translation following ExtractRiverNetwork_glob.m structure
"""

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
from scipy.spatial.distance import cdist
from scipy.spatial import cKDTree
import matplotlib.pyplot as plt
from typing import Tuple, List, Dict, Optional, Union
import geopandas as gpd
from shapely.geometry import Point, LineString

try:
    import topotoolbox as tt
except ImportError:
    print("TopoToolbox for Python non installato. Installare con: pip install topotoolbox")


def extract_river_network_glob(DEM: tt.GridObject, 
                               Amin_km2: float,
                               reach_length_km: float, 
                               mingradient: float,
                               FD: tt.FlowObject,
                               A: tt.GridObject,
                               lon_all: np.ndarray,
                               lat_all: np.ndarray) -> Tuple[List[Dict], tt.StreamObject, tt.FlowObject, tt.GridObject, np.ndarray, np.ndarray, np.ndarray, np.ndarray, tt.GridObject]:
    """
    EXTRACTRIVERNETWORK extracts the river network of a sub-basin based on the
    sub_basin elevations (DEM) and computes attribute table of reaches (river
    segments between two consecutive confluences)
    
    EXACT translation of ExtractRiverNetwork_glob.m
    """
    
    print("   Following EXACT MATLAB ExtractRiverNetwork_glob structure...")
    
    # =================================================================
    # input check (MATLAB lines 25-32)
    # =================================================================
    if mingradient is None:
        mingradient = 0
    
    # =================================================================
    # Preprocessing (MATLAB lines 35-42)
    # =================================================================
    
    # Minimum drainage area in cells.
    # MATLAB: Amin = Amin_km2;%/cellsize_km2;
    # Convert km2 to cells properly for coordinate system
    if DEM.georef and DEM.georef.is_projected:
        cellsize_km2 = (DEM.cellsize / 1000) ** 2
    else:
        # Per coordinate geografiche
        cellsize_km = DEM.cellsize * 111.32
        cellsize_km2 = cellsize_km ** 2
    
    Amin = Amin_km2 / cellsize_km2  # Convert to cells
    
    print(f"   Area threshold: {Amin_km2} km² = {Amin:.0f} cells")
    
    # =================================================================
    # Ritaglio del DEM (MATLAB lines 44-50)
    # =================================================================
    # MATLAB: DEM_fill=DEM;
    DEM_fill = DEM
    
    # =================================================================
    # Flow Directions (MATLAB lines 52-58)
    # =================================================================
    # MATLAB lines are commented, but here we compute from DEM_fill
    # FD = FLOWobj(DEM_fill,'mex',true); %D8
    print("   Computing flow directions from DEM...")
    FD = tt.FlowObject(DEM_fill)
    
    # =================================================================
    # Flow Accumulation and network extraction (MATLAB lines 60-70)
    # =================================================================
    
    # MATLAB: A = flowacc(FD); %flow accumulation matrix
    print("   Computing flow accumulation...")
    A = FD.flow_accumulation()
    
    # MATLAB: W = A > Amin;
    W = A.z > Amin
    
    # MATLAB: S = STREAMobj(FD,W);
    # Correction: use threshold parameter instead of mask (POINT 1)
    S = tt.StreamObject(FD, threshold=Amin)
    
    # MATLAB: S = klargestconncomps(S,1);
    S = S.klargestconncomps(1)
    
    print(f"   Stream network: {len(S.stream)} nodes")
    
    # Store grid info for coordinate conversion
    S.grid_info = {
        'rows': DEM.rows,
        'columns': DEM.columns, 
        'left': DEM.bounds.left,
        'top': DEM.bounds.top,
        'cellsize': DEM.cellsize
    }
    
    # MATLAB: breaknodes=[lon_all lat_all];
    breaknodes = np.column_stack([lon_all, lat_all])
    
    # MATLAB: channelheads = streampoi(S,'channelheads');
    channelheads = S.streampoi('channelheads')
    
    # MATLAB: StrO=streamorder(FD,W);
    StrO = S.streamorder('strahler')
    
    print(f"   Channel heads: {np.sum(channelheads)}")
    
    # =================================================================
    # use the CRS algorithm to postprocess (MATLAB lines 72-85)
    # =================================================================
    
    # MATLAB: useCRS = 0;
    useCRS = 0
    
    if useCRS == 1:
        # Not implemented for now
        pass
    
    # =================================================================
    # Obtain MS (MATLAB lines 87-110)
    # =================================================================
    
    # MATLAB: global ArtificialConfluences
    ArtificialConfluences = None
    
    # MATLAB: if isempty(breaknodes)==0
    if len(breaknodes) > 0:
        
        # MATLAB: [~,~,IX_dam] = snap2stream_mod(S,breaknodes(:,1),breaknodes(:,2), 'maxdist',3000);
        _, _, IX_dam, _ = snap2stream_mod(S, breaknodes[:, 0], breaknodes[:, 1], maxdist=3000)
        
        # Remove NaN results
        valid_mask = ~np.isnan(IX_dam)
        IX_dam = IX_dam[valid_mask].astype(int)
        
        print(f"   Snapped {len(IX_dam)} bridges to stream")
        
        # MATLAB: ArtificialConfluences = ismember(S.IXgrid,IX_dam);
        ArtificialConfluences = np.isin(S.stream, IX_dam)
        
    else:
        # MATLAB: ArtificialConfluences = [];
        ArtificialConfluences = np.array([])
        IX_dam = np.array([])
    
    # MATLAB: reach_length_deg=reach_length_km /(6371*pi/180);
    reach_length_deg = reach_length_km / (6371 * np.pi / 180)  # POINT 2: deg2km conversion
    
    print(f"   Target reach length: {reach_length_km} km = {reach_length_deg:.6f} deg")
    
    # MATLAB: if isempty(reach_length_deg)
    if reach_length_deg is None or reach_length_deg == 0:
        # MATLAB: ReachData = STREAMobj2mapstruct_mod(S);
        ReachData = STREAMobj2mapstruct_mod(S, DEM_fill)
    else:
        # MATLAB: ReachData = STREAMobj2mapstruct_mod(S,'seglength',reach_length_deg);
        ReachData = STREAMobj2mapstruct_mod(S, DEM_fill, seglength=reach_length_deg)
    
    # MATLAB: ReachData(find(cellfun(@isempty,{ReachData.X})))=[];
    ReachData = [r for r in ReachData if 'X' in r and r['X'] is not None and len(r['X']) > 0]
    
    print(f"   Created {len(ReachData)} valid reaches")
    
    # =================================================================
    # Attribute table (MATLAB lines 125-140)
    # =================================================================
    
    # MATLAB: G = gradient8(DEM_fill);
    G = gradient8(DEM_fill)
    
    # MATLAB: [x,y,elevation,~, stro] = STREAMobj2XY(S,DEM_fill,G, StrO);
    x, y, elevation, _, stro = STREAMobj2XY(S, DEM_fill, G, StrO)
    
    print(f"   Extracted {len(x)} stream points for attribute calculation")
    
    # =================================================================
    # FN/TN ID attribution (MATLAB lines 145-170)
    # =================================================================
    
    # MATLAB: reach_ID = (1:length(ReachData))';
    reach_ID = np.arange(1, len(ReachData) + 1)
    
    # MATLAB: Find From Node (FN)
    x_FN = np.array([reach['X'][0] for reach in ReachData])
    y_FN = np.array([reach['Y'][0] for reach in ReachData])
    
    # MATLAB: Find To Node (TN)  
    x_TN = np.array([reach['X'][-1] for reach in ReachData])
    y_TN = np.array([reach['Y'][-1] for reach in ReachData])
    
    # =================================================================
    # Compute nodes indexes (MATLAB lines 175-195)
    # =================================================================
    
    # MATLAB: indexes of FN and TN nodes in the arrays x,y,elevation
    FN_indexes = find_node_indexes_matlab(x_FN, y_FN, x, y)
    TN_indexes = find_node_indexes_matlab(x_TN, y_TN, x, y)
    
    # MATLAB: indexes in S.x, S.y arrays  
    S_x, S_y = get_stream_xy_coords(S, DEM_fill)
    FN_indexes_S = find_node_indexes_matlab(x_FN, y_FN, S_x, S_y)
    TN_indexes_S = find_node_indexes_matlab(x_TN, y_TN, S_x, S_y)
    
    # =================================================================
    # Compute attributes matrix B (MATLAB lines 200-220)
    # =================================================================
    
    # MATLAB: lengths = deg2km(S.distance(FN_indexes_S(:,1)))*1000 - deg2km(S.distance(TN_indexes_S(:,1)))*1000;
    distances_S = calculate_stream_distances(S, DEM_fill)
    
    lengths = []
    for i in range(len(ReachData)):
        if FN_indexes_S[i] >= 0 and TN_indexes_S[i] >= 0:
            # Convert from degrees to km to meters (POINT 2)
            len_FN = deg2km(distances_S[FN_indexes_S[i]]) * 1000
            len_TN = deg2km(distances_S[TN_indexes_S[i]]) * 1000
            lengths.append(abs(len_FN - len_TN))
        else:
            # Fallback calculation from coordinates
            dx = x_TN[i] - x_FN[i]
            dy = y_TN[i] - y_FN[i]
            lengths.append(deg2km(np.sqrt(dx**2 + dy**2)) * 1000)
    
    length_m = np.array(lengths)
    
    # MATLAB: slopes = (elevation(FN_indexes(:,1)) - elevation(TN_indexes(:,1)))./length_m;
    slopes = []
    for i in range(len(ReachData)):
        if FN_indexes[i] >= 0 and TN_indexes[i] >= 0 and length_m[i] > 0:
            elev_diff = elevation[FN_indexes[i]] - elevation[TN_indexes[i]]
            slope = elev_diff / length_m[i]
        else:
            slope = mingradient
        slopes.append(slope)
    
    slopes = np.array(slopes)
    
    # MATLAB: if useCRS == 0, slopes(slopes<mingradient) = mingradient;
    if useCRS == 0:
        slopes[slopes < mingradient] = mingradient
    
    # MATLAB: B = [reach_ID, x_FN, y_FN, elevation(FN_indexes(:,1)), x_TN, y_TN, elevation(TN_indexes(:,1)), stro(FN_indexes(:,1)), length_m, slopes];
    B = build_attributes_matrix(reach_ID, x_FN, y_FN, x_TN, y_TN, elevation, stro, FN_indexes, TN_indexes, length_m, slopes)
    
    # =================================================================
    # FN-TN matrix (MATLAB lines 230-270)
    # =================================================================
    
    # MATLAB: uniqueNodes = unique( [ x_FN,y_FN ; x_TN,y_TN ] , 'rows');
    all_nodes = np.vstack([np.column_stack([x_FN, y_FN]), np.column_stack([x_TN, y_TN])])
    uniqueNodes = np.unique(all_nodes, axis=0)
    
    # MATLAB: idNodes = (1:length(uniqueNodes))';
    idNodes = np.arange(1, len(uniqueNodes) + 1)
    uniqueNodes = np.column_stack([idNodes, uniqueNodes])
    
    # Find node IDs for FN and TN
    idFN, idTN = assign_node_ids_matlab(x_FN, y_FN, x_TN, y_TN, uniqueNodes)
    
    FN_TN_messy_matrix = np.column_stack([reach_ID, idFN, idTN])
    
    # =================================================================
    # Remove duplicates (MATLAB lines 275-290)
    # =================================================================
    
    # MATLAB: find duplicate reaches and delete them
    ReachData, FN_TN_messy_matrix, x_FN, y_FN, x_TN, y_TN, reach_ID, B = remove_duplicate_reaches(
        ReachData, FN_TN_messy_matrix, x_FN, y_FN, x_TN, y_TN, reach_ID, B)
    
    # =================================================================
    # reassign node IDs (MATLAB lines 295-300)
    # =================================================================
    
    # MATLAB: [ new_idFN, new_idTN, ~ ] = reassignNodeIDs(FN_TN_messy_matrix(:,2), FN_TN_messy_matrix(:,3) );
    new_idFN, new_idTN, _ = reassignNodeIDs(FN_TN_messy_matrix[:, 1], FN_TN_messy_matrix[:, 2])
    
    FN_TN_ordered_matrix = np.column_stack([reach_ID, new_idFN, new_idTN])
    
    # =================================================================
    # new attribute matrix (MATLAB lines 305-320)
    # =================================================================
    
    # MATLAB: attributes = [FN_TN_ordered_matrix B(:,2:end)];
    attributes = np.column_stack([FN_TN_ordered_matrix, B[:, 1:]])
    
    # =================================================================
    # add attributes to MS (MATLAB lines 360-380)
    # =================================================================
    
    # Add all MATLAB attributes to ReachData
    for i in range(len(ReachData)):
        if i < len(attributes):
            ReachData[i].update({
                'reach_id': int(attributes[i, 0]),
                'FromN': int(attributes[i, 1]),
                'ToN': int(attributes[i, 2]),
                'el_FN': float(attributes[i, 5]),
                'el_TN': float(attributes[i, 8]),
                'Slope': float(attributes[i, 11]),
                'Length': float(attributes[i, 10]),
                'StrO': float(attributes[i, 9]),
                'x_FN': float(attributes[i, 3]),
                'y_FN': float(attributes[i, 4]),
                'x_TN': float(attributes[i, 6]),
                'y_TN': float(attributes[i, 7])
            })
            
            # Add geometry
            if 'X' in ReachData[i] and 'Y' in ReachData[i]:
                coords = list(zip(ReachData[i]['X'], ReachData[i]['Y']))
                ReachData[i]['geometry'] = LineString(coords)
    
    # =================================================================
    # FINAL OUTPUTS (MATLAB lines 390-400)
    # =================================================================
    
    # MATLAB: breaknodes = IX_dam;
    breaknodes = IX_dam
    
    # MATLAB: channelheads = coord2ind(DEM_fill,channelheads(:,1),channelheads(:,2));
    # Convert channelheads usando stesso approccio dell'outlet
    channelheads_linear = []
    stream_coords = get_stream_coordinates_from_indices(S)
    for i, is_head in enumerate(channelheads):
        if is_head and i < len(stream_coords):
            lon, lat = stream_coords[i]
            # Converti coordinate in indici grid
            col = int((lon - DEM_fill.bounds.left) / DEM_fill.cellsize)
            row = int((DEM_fill.bounds.top - lat) / DEM_fill.cellsize)
            # Converti in indice lineare (ordine Fortran)
            if 0 <= row < DEM_fill.rows and 0 <= col < DEM_fill.columns:
                linear_idx = row + col * DEM_fill.rows
                channelheads_linear.append(linear_idx)
    channelheads_linear = np.array(channelheads_linear)
    
    # MATLAB: xy_TN=coord2ind(DEM_fill,x_TN(:),y_TN(:));
    # Convert TN coordinates usando stesso approccio dell'outlet
    xy_TN = []
    for x, y in zip(x_TN, y_TN):
        col = int((x - DEM_fill.bounds.left) / DEM_fill.cellsize)
        row = int((DEM_fill.bounds.top - y) / DEM_fill.cellsize)
        if 0 <= row < DEM_fill.rows and 0 <= col < DEM_fill.columns:
            linear_idx = row + col * DEM_fill.rows  # Fortran order
            xy_TN.append(linear_idx)
        else:
            xy_TN.append(0)
    xy_TN = np.array(xy_TN)
    
    # MATLAB: xy_FN=coord2ind(DEM_fill,x_FN(:),y_FN(:));
    # Convert FN coordinates usando stesso approccio dell'outlet
    xy_FN = []
    for x, y in zip(x_FN, y_FN):
        col = int((x - DEM_fill.bounds.left) / DEM_fill.cellsize)
        row = int((DEM_fill.bounds.top - y) / DEM_fill.cellsize)
        if 0 <= row < DEM_fill.rows and 0 <= col < DEM_fill.columns:
            linear_idx = row + col * DEM_fill.rows  # Fortran order
            xy_FN.append(linear_idx)
        else:
            xy_FN.append(0)
    xy_FN = np.array(xy_FN)
    
    print(f"   Final: {len(ReachData)} reaches with full MATLAB attributes")
    
    return ReachData, S, FD, DEM_fill, breaknodes, channelheads_linear, xy_FN, xy_TN, A


# =================================================================
# HELPER FUNCTIONS IMPLEMENTING MATLAB LOGIC EXACTLY
# =================================================================

def snap2stream_mod(S, x, y, snapto='all', maxdist=np.inf, streamorder=None, plot=False):
    """
    Fixed implementation of snap2stream_mod.m
    Properly handles coordinate systems and snapping
    """
    
    # Convert input to arrays
    x = np.atleast_1d(np.array(x).flatten())
    y = np.atleast_1d(np.array(y).flatten())
    
    # Get DEM info from StreamObject
    if hasattr(S, 'grid_info') and S.grid_info is not None:
        grid_info = S.grid_info
    else:
        raise ValueError("StreamObject missing grid_info")
    
    # Get all stream points coordinates
    stream_coords = []
    stream_indices = []
    
    # Convert linear indices to coordinates
    for linear_idx in S.stream:
        # Convert linear index to row/col (Fortran order)
        row = linear_idx % grid_info['rows']
        col = linear_idx // grid_info['rows']
        
        # Convert to geographic coordinates
        lon = grid_info['left'] + (col + 0.5) * grid_info['cellsize']
        lat = grid_info['top'] - (row + 0.5) * grid_info['cellsize']
        
        stream_coords.append([lon, lat])
        stream_indices.append(linear_idx)
    
    stream_coords = np.array(stream_coords)
    stream_indices = np.array(stream_indices)
    
    if len(stream_coords) == 0:
        print("Warning: No stream coordinates found")
        return (np.full_like(x, np.nan), 
                np.full_like(y, np.nan),
                np.full_like(x, np.nan, dtype=float),
                np.full_like(x, np.inf))
    
    # Apply filters based on snapto parameter
    mask = np.ones(len(stream_coords), dtype=bool)
    
    if snapto == 'confluence':
        # Get confluences (nodes with multiple upstream connections)
        confluence_mask = S.streampoi('confluences')
        if len(confluence_mask) == len(S.stream):
            mask = mask & confluence_mask
    elif snapto == 'outlet':
        outlet_mask = S.streampoi('outlets')
        if len(outlet_mask) == len(S.stream):
            mask = mask & outlet_mask
    elif snapto == 'channelhead':
        channelhead_mask = S.streampoi('channelheads')
        if len(channelhead_mask) == len(S.stream):
            mask = mask & channelhead_mask
    
    # Apply streamorder filter if specified
    if streamorder is not None:
        so = S.streamorder('strahler')
        if len(so) == len(S.stream):
            mask = mask & (so == streamorder)
    
    # Filter coordinates and indices
    filtered_coords = stream_coords[mask]
    filtered_indices = stream_indices[mask]
    
    if len(filtered_coords) == 0:
        print(f"Warning: No stream points match criteria (snapto={snapto})")
        return (np.full_like(x, np.nan),
                np.full_like(y, np.nan),
                np.full_like(x, np.nan, dtype=float),
                np.full_like(x, np.inf))
    
    # Find nearest stream point for each input point
    xn = np.zeros_like(x, dtype=float)
    yn = np.zeros_like(y, dtype=float)
    ix = np.zeros_like(x, dtype=float)
    d = np.zeros_like(x, dtype=float)
    
    for i in range(len(x)):
        # Calculate distances to all filtered stream points
        distances = np.sqrt((filtered_coords[:, 0] - x[i])**2 + 
                           (filtered_coords[:, 1] - y[i])**2)
        
        # Find minimum distance
        min_idx = np.argmin(distances)
        min_dist = distances[min_idx]
        
        # Convert geographic distance to meters for maxdist check
        min_dist_m = deg2km(min_dist) * 1000
        
        if min_dist_m <= maxdist:
            xn[i] = filtered_coords[min_idx, 0]
            yn[i] = filtered_coords[min_idx, 1]
            ix[i] = filtered_indices[min_idx]
            d[i] = min_dist_m
        else:
            xn[i] = np.nan
            yn[i] = np.nan
            ix[i] = np.nan
            d[i] = min_dist_m
    
    # Debug output
    n_snapped = np.sum(~np.isnan(xn))
    print(f"   Snapped {n_snapped}/{len(x)} points (maxdist={maxdist}m)")
    if n_snapped > 0:
        print(f"   Average snap distance: {np.nanmean(d):.1f}m")
        print(f"   Max snap distance: {np.nanmax(d):.1f}m")
    
    return xn, yn, ix, d


def get_stream_coordinates_from_indices(S):
    """
    Extract coordinates from StreamObject using grid_info
    Returns coordinates in the same order as S.stream indices
    """
    if hasattr(S, 'grid_info') and S.grid_info is not None:
        grid_info = S.grid_info
        coords = []
        
        for linear_idx in S.stream:
            # Convert linear index to row/col (Fortran order)
            row = linear_idx % grid_info['rows']
            col = linear_idx // grid_info['rows']
            
            # Convert to geographic coordinates
            x = grid_info['left'] + (col + 0.5) * grid_info['cellsize']
            y = grid_info['top'] - (row + 0.5) * grid_info['cellsize']
            coords.append([x, y])
        
        return np.array(coords)
    else:
        # Try to get coordinates from xy() method
        try:
            segments = S.xy()
            all_points = []
            for segment in segments:
                all_points.extend(segment)
            
            # Remove duplicates while preserving order
            coords = []
            seen = set()
            for point in all_points:
                point_tuple = tuple(point)
                if point_tuple not in seen:
                    seen.add(point_tuple)
                    coords.append(point)
            
            return np.array(coords)
        except Exception as e:
            print(f"Warning: Could not extract stream coordinates: {e}")
            # Fallback: return dummy coordinates
            n_nodes = len(S.stream) if hasattr(S, 'stream') else 100
            return np.column_stack([np.arange(n_nodes, dtype=float), 
                                   np.zeros(n_nodes)])


def deg2km(deg_distance):
    """Convert degrees to kilometers at the equator"""
    return deg_distance * (6371 * np.pi / 180)


def km2deg(km_distance):
    """Convert kilometers to degrees at the equator"""
    return km_distance / (6371 * np.pi / 180)


def verify_bridge_coordinates(bridges, dem_bounds):
    """
    Verify that bridge coordinates are within DEM bounds
    """
    print("\n=== BRIDGE COORDINATE VERIFICATION ===")
    
    for i, bridge in enumerate(bridges):
        lon = bridge['lon']
        lat = bridge['lat']
        
        in_bounds = (dem_bounds.left <= lon <= dem_bounds.right and
                    dem_bounds.bottom <= lat <= dem_bounds.top)
        
        print(f"Bridge {i} ({bridge['name']}): lon={lon:.6f}, lat={lat:.6f} - {'OK' if in_bounds else 'OUT OF BOUNDS'}")
    
    print(f"DEM bounds: lon=[{dem_bounds.left:.6f}, {dem_bounds.right:.6f}], lat=[{dem_bounds.bottom:.6f}, {dem_bounds.top:.6f}]")
    
    return True

def STREAMobj2mapstruct_mod(S, DEM, seglength=None):
    """Implementation of STREAMobj2mapstruct_mod.m"""
    reaches = []
    
    try:
        segments = S.xy()
        for i, segment in enumerate(segments):
            if len(segment) >= 2:
                if seglength is not None:
                    sub_reaches = split_segment_by_length_deg(segment, seglength)
                    for j, sub_segment in enumerate(sub_reaches):
                        reach = {
                            'X': [pt[0] for pt in sub_segment],
                            'Y': [pt[1] for pt in sub_segment],
                            'segment_id': i,
                            'sub_id': j
                        }
                        reaches.append(reach)
                else:
                    reach = {
                        'X': [pt[0] for pt in segment],
                        'Y': [pt[1] for pt in segment],
                        'segment_id': i,
                        'sub_id': 0
                    }
                    reaches.append(reach)
    except:
        # Fallback: create simple reaches
        coords = get_stream_coordinates_from_indices(S)
        if len(coords) >= 2:
            reach = {
                'X': coords[:, 0].tolist(),
                'Y': coords[:, 1].tolist(),
                'segment_id': 0,
                'sub_id': 0
            }
            reaches.append(reach)
    
    return reaches


def split_segment_by_length_deg(segment, target_length_deg):
    """Split segment by target length in degrees"""
    if len(segment) < 2:
        return [segment]
    
    segment = np.array(segment)
    distances = [0]
    for i in range(1, len(segment)):
        dist = np.sqrt((segment[i][0] - segment[i-1][0])**2 + 
                      (segment[i][1] - segment[i-1][1])**2)
        distances.append(distances[-1] + dist)
    
    total_length = distances[-1]
    
    if total_length <= target_length_deg:
        return [segment.tolist()]
    
    n_reaches = max(1, int(np.ceil(total_length / target_length_deg)))
    reaches = []
    reach_length = total_length / n_reaches
    
    for i in range(n_reaches):
        start_dist = i * reach_length
        end_dist = (i + 1) * reach_length
        
        start_idx = 0
        end_idx = len(segment) - 1
        
        for j, d in enumerate(distances):
            if d >= start_dist and start_idx == 0:
                start_idx = j
            if d >= end_dist:
                end_idx = j
                break
        
        if start_idx < end_idx:
            reaches.append(segment[start_idx:end_idx+1].tolist())
    
    return reaches if reaches else [segment.tolist()]


def gradient8(DEM):
    """Implementation of MATLAB gradient8"""
    try:
        return DEM.gradient('horn')
    except:
        # Fallback: simple gradient calculation
        grad_data = np.gradient(DEM.z)
        grad_magnitude = np.sqrt(grad_data[0]**2 + grad_data[1]**2)
        return DEM.duplicate_with_new_data(grad_magnitude)


def STREAMobj2XY(S, DEM, G, StrO):
    """Implementation of MATLAB STREAMobj2XY"""
    try:
        # Get stream coordinates
        coords = get_stream_coordinates_from_indices(S)
        x = coords[:, 0]
        y = coords[:, 1]
        
        # Get elevations at stream points
        elevation = []
        gradient_vals = []
        stro = []
        
        for i, (xi, yi) in enumerate(zip(x, y)):
            # Convert to grid indices
            col = int((xi - DEM.bounds.left) / DEM.cellsize)
            row = int((DEM.bounds.top - yi) / DEM.cellsize)
            
            if 0 <= row < DEM.rows and 0 <= col < DEM.columns:
                elevation.append(float(DEM.z[row, col]))
                gradient_vals.append(float(G.z[row, col]))
                if i < len(StrO):
                    stro.append(float(StrO[i]))
                else:
                    stro.append(1.0)
            else:
                elevation.append(0.0)
                gradient_vals.append(0.0)
                stro.append(1.0)
        
        return np.array(x), np.array(y), np.array(elevation), np.array(gradient_vals), np.array(stro)
        
    except Exception as e:
        print(f"Warning: STREAMobj2XY failed ({e}), using fallback")
        # Fallback
        n = max(len(S.stream), 10)
        return (np.arange(n, dtype=float), np.arange(n, dtype=float), 
                np.zeros(n), np.zeros(n), np.ones(n))


def find_node_indexes_matlab(x_target, y_target, x_stream, y_stream):
    """Find node indexes following MATLAB logic"""
    indexes = []
    for i in range(len(x_target)):
        # Find matching coordinates
        matches = np.where((np.abs(x_stream - x_target[i]) < 1e-6) & 
                          (np.abs(y_stream - y_target[i]) < 1e-6))[0]
        if len(matches) > 0:
            indexes.append(matches[0])
        else:
            indexes.append(-1)
    return np.array(indexes)


def get_stream_xy_coords(S, DEM):
    """Get S.x, S.y equivalent coordinates"""
    coords = get_stream_coordinates_from_indices(S)
    return coords[:, 0], coords[:, 1]


def calculate_stream_distances(S, DEM):
    """Calculate stream distances"""
    try:
        return S.distance()
    except:
        # Fallback: cumulative distances
        coords = get_stream_coordinates_from_indices(S)
        distances = [0]
        for i in range(1, len(coords)):
            dist = np.sqrt((coords[i][0] - coords[i-1][0])**2 + 
                          (coords[i][1] - coords[i-1][1])**2)
            distances.append(distances[-1] + dist)
        return np.array(distances)


def build_attributes_matrix(reach_ID, x_FN, y_FN, x_TN, y_TN, elevation, stro, FN_indexes, TN_indexes, length_m, slopes):
    """Build MATLAB-style attributes matrix B"""
    B = []
    for i in range(len(reach_ID)):
        elev_fn = elevation[FN_indexes[i]] if FN_indexes[i] >= 0 else 0.0
        elev_tn = elevation[TN_indexes[i]] if TN_indexes[i] >= 0 else 0.0
        stro_val = stro[FN_indexes[i]] if FN_indexes[i] >= 0 else 1.0
        
        row = [
            reach_ID[i], x_FN[i], y_FN[i], elev_fn,
            x_TN[i], y_TN[i], elev_tn, stro_val, 
            length_m[i], slopes[i]
        ]
        B.append(row)
    
    return np.array(B)


def assign_node_ids_matlab(x_FN, y_FN, x_TN, y_TN, uniqueNodes):
    """Assign node IDs following MATLAB logic"""
    idFN = []
    idTN = []
    
    for i in range(len(x_FN)):
        # Find FN
        fn_matches = np.where((np.abs(uniqueNodes[:, 1] - x_FN[i]) < 1e-6) & 
                             (np.abs(uniqueNodes[:, 2] - y_FN[i]) < 1e-6))[0]
        if len(fn_matches) > 0:
            idFN.append(int(uniqueNodes[fn_matches[0], 0]))
        else:
            idFN.append(1)
        
        # Find TN
        tn_matches = np.where((np.abs(uniqueNodes[:, 1] - x_TN[i]) < 1e-6) & 
                             (np.abs(uniqueNodes[:, 2] - y_TN[i]) < 1e-6))[0]
        if len(tn_matches) > 0:
            idTN.append(int(uniqueNodes[tn_matches[0], 0]))
        else:
            idTN.append(2)
    
    return np.array(idFN), np.array(idTN)


def remove_duplicate_reaches(ReachData, FN_TN_messy_matrix, x_FN, y_FN, x_TN, y_TN, reach_ID, B):
    """Remove duplicate reaches following MATLAB logic"""
    # Find duplicates based on FromNode (column 1 of FN_TN_messy_matrix)
    _, unique_indices = np.unique(FN_TN_messy_matrix[:, 1], return_index=True)
    
    # Keep only unique reaches
    ReachData = [ReachData[i] for i in unique_indices]
    FN_TN_messy_matrix = FN_TN_messy_matrix[unique_indices]
    x_FN = x_FN[unique_indices]
    y_FN = y_FN[unique_indices] 
    x_TN = x_TN[unique_indices]
    y_TN = y_TN[unique_indices]
    reach_ID = reach_ID[unique_indices]
    B = B[unique_indices]
    
    return ReachData, FN_TN_messy_matrix, x_FN, y_FN, x_TN, y_TN, reach_ID, B


def reassignNodeIDs(from_nodes, to_nodes):
    """Translation of reassignNodeIDs.m"""
    new_from_nodes = np.arange(1, len(from_nodes) + 1)
    transfer_table = dict(zip(from_nodes, new_from_nodes))
    
    new_to_nodes = np.zeros_like(to_nodes)
    outlet_nodes = []
    
    for i, old_tn in enumerate(to_nodes):
        if old_tn in transfer_table:
            new_to_nodes[i] = transfer_table[old_tn]
        else:
            new_to_nodes[i] = new_from_nodes[i]
            outlet_nodes.append(new_to_nodes[i])
    
    return new_from_nodes, new_to_nodes, np.array(outlet_nodes)


def get_channelheads_coords(S, DEM, channelheads_mask):
    """Get coordinates of channel heads"""
    coords = get_stream_coordinates_from_indices(S)
    if len(channelheads_mask) == len(coords):
        heads = coords[channelheads_mask]
        if len(heads) > 0:
            return heads[:, 0], heads[:, 1]
    return np.array([]), np.array([])


def coord2ind_array(DEM, x_array, y_array):
    """Convert coordinate arrays to linear indices"""
    indices = []
    for x, y in zip(x_array, y_array):
        col = int((x - DEM.bounds.left) / DEM.cellsize)
        row = int((DEM.bounds.top - y) / DEM.cellsize)
        
        if 0 <= row < DEM.rows and 0 <= col < DEM.columns:
            indices.append(row + col * DEM.rows)  # Fortran order
        else:
            indices.append(0)
    
    return np.array(indices)


# =================================================================
# EXISTING FUNCTIONS (keep for compatibility)
# =================================================================

def river_geometry_giandotti(reach_data: List[Dict],
                           s: tt.StreamObject,
                           dem_fill: tt.GridObject, 
                           breaknodes: np.ndarray,
                           a: tt.GridObject,
                           fd: tt.FlowObject) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Calculate hydrological parameters using Giandotti formula."""
    n_nodes = len(breaknodes)
    tau_b = np.zeros(n_nodes)
    l_asta = np.zeros(n_nodes)
    ab = np.zeros(n_nodes)
    hm = np.zeros(n_nodes)
    
    try:
        upstream_dist = s.upstream_distance()
    except:
        upstream_dist = np.arange(len(s.stream), dtype=float) * 100  # Fallback
    
    for i, node_idx in enumerate(breaknodes):
        stream_node = np.where(s.stream == node_idx)[0]
        if len(stream_node) == 0:
            tau_b[i] = 2.0
            l_asta[i] = 5.0
            ab[i] = 10.0
            hm[i] = 100.0
            continue
            
        stream_node = stream_node[0]
        
        if a.georef and a.georef.is_projected:
            cellsize_km2 = (a.cellsize / 1000) ** 2
        else:
            cellsize_km = a.cellsize * 111.32
            cellsize_km2 = cellsize_km ** 2
            
        ab[i] = a.z.flat[node_idx] * cellsize_km2
        l_asta[i] = upstream_dist[stream_node] / 1000  # Convert m to km
        
        try:
            basin = fd.drainagebasins(np.array([node_idx]))
            basin_mask = basin.z == 1
            
            if np.any(basin_mask):
                basin_elevations = dem_fill.z[basin_mask]
                outlet_elevation = dem_fill.z.flat[node_idx]
                hm[i] = np.mean(basin_elevations) - outlet_elevation
            else:
                hm[i] = 100
        except:
            hm[i] = 100
            
        tau_b[i] = (4 * np.sqrt(ab[i]) + 1.5 * l_asta[i]) / (0.8 * np.sqrt(max(hm[i], 1)))
        
        if np.isinf(tau_b[i]) or tau_b[i] <= 0:
            tau_b[i] = 1.0
    
    return tau_b, l_asta, ab, hm


def foca_idf(reach_data: List[Dict],
            breaknodes: np.ndarray,
            fd: tt.FlowObject,
            tau_b: np.ndarray,
            a_tr: tt.GridObject,
            n_tr: tt.GridObject, 
            s_cn: tt.GridObject) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Calculate design precipitation using IDF curves and SCS-CN method."""
    n_nodes = len(breaknodes)
    h_t = np.zeros(n_nodes)
    s_mean = np.zeros(n_nodes)
    p_t = np.zeros(n_nodes)
    
    for i, node_idx in enumerate(breaknodes):
        try:
            basin = fd.drainagebasins(np.array([node_idx]))
            basin_mask = basin.z == 1
            
            if not np.any(basin_mask):
                h_t[i] = 10.0
                s_mean[i] = 50.0
                p_t[i] = 5.0
                continue
                
            # Extract IDF parameters for basin
            a_values = a_tr.z[basin_mask]
            n_values = n_tr.z[basin_mask]
            
            valid_mask = ~(np.isnan(a_values) | np.isnan(n_values))
            if np.any(valid_mask):
                a_values = a_values[valid_mask]
                n_values = n_values[valid_mask]
                h_tr_values = a_values * (tau_b[i] ** n_values)
                h_t[i] = np.mean(h_tr_values)
            else:
                h_t[i] = 10.0
                
            # Extract S parameter for basin
            s_values = s_cn.z[basin_mask]
            s_values = s_values[~np.isinf(s_values) & ~np.isnan(s_values)]
            
            if len(s_values) > 0:
                s_mean[i] = np.mean(s_values)
            else:
                s_mean[i] = 50.0
                
            # Calculate initial abstraction (5% of S)
            ia = 0.05 * s_mean[i]
            
            # SCS runoff equation: P = (h-Ia)²/(h-Ia+S)
            if h_t[i] > ia:
                p_t[i] = ((h_t[i] - ia) ** 2) / (h_t[i] - ia + s_mean[i])
            else:
                p_t[i] = 0.02
                
            if np.isnan(p_t[i]):
                p_t[i] = 0.02
                
        except Exception as e:
            print(f"   Warning: Error processing node {i}: {e}")
            h_t[i] = 10.0
            s_mean[i] = 50.0
            p_t[i] = 5.0
    
    return p_t, h_t, s_mean


def reassign_node_ids(from_nodes: np.ndarray, to_nodes: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Reassign node IDs to be continuous after network processing."""
    return reassignNodeIDs(from_nodes, to_nodes)